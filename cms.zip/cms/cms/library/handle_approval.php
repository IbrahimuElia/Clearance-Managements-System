<?php
require_once '../config/conn.php';

// Get form data
$requestId = intval($_POST['clear_id']);
$approve = isset($_POST['approve']);
$reject = isset($_POST['reject']);

if ($approve && !$reject) {
    // Approval process
    $status = 'Pending Librarian Approval';
    $stmt = $conn->prepare("UPDATE clearance_requests SET status = ?, rejected_status = 'Approved', workshop_view_reject = 'No' WHERE clear_id = ?");
    
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("si", $status, $requestId);

    if ($stmt->execute()) {
        // Update the dashboard status
        $result = $conn->query("SELECT student_id FROM clearance_requests WHERE clear_id = $requestId");

        if ($result && $row = $result->fetch_assoc()) {
            $studentId = (int)$row['student_id'];
            $dashboardStatus = 'Workshop Approved';
            $updateStmt = $conn->prepare("UPDATE students SET workshop_dashboard_status = ? WHERE student_id = ?");

            if (!$updateStmt) {
                die("Prepare failed: " . $conn->error);
            }

            $updateStmt->bind_param("si", $dashboardStatus, $studentId);

            if ($updateStmt->execute()) {
                echo "Request approved by Workshop and student dashboard status updated.";
            } else {
                echo "Error updating dashboard status: " . $updateStmt->error;
            }
            $updateStmt->close();
        } else {
            echo "No student found for the given request ID.";
        }
    } else {
        echo "Error updating request status: " . $stmt->error;
    }
} elseif ($reject && !$approve) {
    // Rejection process
    $status = 'Workshop Rejected';
    $debtItems = isset($_POST['debt_items']) ? json_encode($_POST['debt_items']) : null; // Convert to JSON

    // Prepare the SQL query to update the request status
    $stmt = $conn->prepare("UPDATE clearance_requests SET status = ?, rejected_status = 'Workshop Rejected', workshop_view_reject = 'No', debt_items = ? WHERE clear_id = ?");

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind the parameters
    $stmt->bind_param("ssi", $status, $debtItems, $requestId);

    if ($stmt->execute()) {
        // Update the dashboard status
        $result = $conn->query("SELECT student_id FROM clearance_requests WHERE clear_id = $requestId");

        if ($result && $row = $result->fetch_assoc()) {
            $studentId = (int)$row['student_id'];
            $dashboardStatus = 'Workshop Rejected';
            $updateStmt = $conn->prepare("UPDATE students SET workshop_dashboard_status = ? WHERE student_id = ?");
            
            if (!$updateStmt) {
                die("Prepare failed: " . $conn->error);
            }

            $updateStmt->bind_param("si", $dashboardStatus, $studentId);
            if ($updateStmt->execute()) {
                echo "Request rejected by Workshop and student dashboard status updated.";
            } else {
                echo "Error updating dashboard status: " . $updateStmt->error;
            }
            $updateStmt->close();
        } else {
            echo "No student found for the given request ID.";
        }
    } else {
        echo "Error updating request status: " . $stmt->error;
    }
} else {
    die("Invalid action. Please choose either approve or reject.");
}

// Close the main statement and connection

?>
