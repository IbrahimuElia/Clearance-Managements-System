<?php
require_once '../config/conn.php';

// Check if 'clear_id' is set
if (!isset($_POST['clear_id'])) {
    die("Missing clear_id in the request.");
}

// Get form data
$requestId = intval($_POST['clear_id']);
$approve = isset($_POST['approve']);
$reject = isset($_POST['reject']);

// Check for valid action
if (!($approve || $reject)) {
    die("Invalid action. Please choose either approve or reject.");
}

// Prepare to update request status and dashboard status
if ($approve && !$reject) {
    // Approval process
    $sql = "SELECT status FROM clearance_requests WHERE clear_id = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("i", $requestId);
    $stmt->execute();
    $result = $stmt->get_result();
    $request = $result->fetch_assoc();
    
    if ($request === null) {
        die("Request not found.");
    }

    if ($request['status'] === 'Processing Librarian Reapply') {
        $status = 'Completed';
        $stmt = $conn->prepare("UPDATE clearance_requests SET status = ?, rejected_status = NULL, librarian_view_reject = 'No' WHERE clear_id = ?");
        
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }
        
        $stmt->bind_param("si", $status, $requestId);
        if ($stmt->execute()) {
            // Retrieve student ID
            $stmt = $conn->prepare("SELECT student_id FROM clearance_requests WHERE clear_id = ?");
            
            if (!$stmt) {
                die("Prepare failed: " . $conn->error);
            }
            
            $stmt->bind_param("i", $requestId);
            $stmt->execute();
            $studentResult = $stmt->get_result();
            
            if ($studentResult->num_rows === 0) {
                die("Student not found.");
            }
            
            $studentId = (int)$studentResult->fetch_assoc()['student_id'];
            $dashboardStatus = 'Librarian Approved';
            $updateStmt = $conn->prepare("UPDATE students SET librarian_dashboard_status = ? WHERE student_id = ?");
            
            if (!$updateStmt) {
                die("Prepare failed: " . $conn->error);
            }
            
            $updateStmt->bind_param("si", $dashboardStatus, $studentId);
            if ($updateStmt->execute()) {
                echo "Request approved by Library and student dashboard status updated.";
            } else {
                echo "Error updating student dashboard status: " . $updateStmt->error;
            }
            $updateStmt->close();
        } else {
            echo "Error updating request status: " . $stmt->error;
        }
    } else {
        echo "Request is not in the correct status for Library approval.";
    }
} elseif ($reject && !$approve) {
    // Rejection process
    $status = 'Librarian Rejected';
    $debtItems = isset($_POST['debt_items']) ? json_encode($_POST['debt_items']) : null; // Convert to JSON

    $stmt = $conn->prepare("UPDATE clearance_requests SET status = ?, rejected_status = 'Librarian Rejected', librarian_view_reject = 'No', debt_items = ? WHERE clear_id = ?");
    
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind the parameters
    $stmt->bind_param("ssi", $status, $debtItems, $requestId);

    if ($stmt->execute()) {
        // Update the dashboard status
        $result = $conn->query("SELECT student_id FROM clearance_requests WHERE clear_id = $requestId");

        if ($result && $row = $result->fetch_assoc()) {
            $studentId = (int)$row['student_id'];
            $dashboardStatus = 'Librarian Rejected';
            $updateStmt = $conn->prepare("UPDATE students SET librarian_dashboard_status = ? WHERE student_id = ?");
            
            if (!$updateStmt) {
                die("Prepare failed: " . $conn->error);
            }

            $updateStmt->bind_param("si", $dashboardStatus, $studentId);
            if ($updateStmt->execute()) {
                echo "Request rejected by Librarian and student dashboard status updated.";
            } else {
                echo "Error updating dashboard status: " . $updateStmt->error;
            }
            $updateStmt->close();
        } else {
            echo "No student found for the given request ID.";
        }
    } else {
        echo "Error updating request status: " . $stmt->error;
    }
}

// Close the main statement and connection

?>
