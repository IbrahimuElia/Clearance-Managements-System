<?php
require_once '../config/conn.php';

// Get request ID from the query string
$requestId = intval($_GET['id']);

// Fetch request details
$sql = "SELECT * FROM clearance_requests WHERE clear_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $requestId);
$stmt->execute();
$result = $stmt->get_result();
$request = $result->fetch_assoc();

if (!$request) {
    die("Request not found.");
}

// Fetch student details
$studentId = $request['student_id'];
$sql = "SELECT * FROM students WHERE student_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $studentId);
$stmt->execute();
$student = $stmt->get_result()->fetch_assoc();

// Display request details


// Display the approval form
echo "<form action='handle_library_approval.php' method='post'>
        <input type='hidden' name='id' value='" . htmlspecialchars($request['clear_id']) . "'>";

if ($request['status'] == 'Pending Workshop Approval') {
    echo "<input type='submit' name='approve' value='Approve'>
          <input type='submit' name='reject' value='Reject'>
          </form>";
} else {
    echo "<p>This request is not pending Workshop approval.</p>";
}


$stmt->close();
$conn->close();
?>
