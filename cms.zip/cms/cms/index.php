<?php 
session_start(); // Start session to access session variables
?>
<!DOCTYPE html>
<html>
<head>
  <title>Login-CMS</title>
  <link rel="stylesheet" href="login.css">
</head>
<body>
  <form action="config/staff_login.php" method="POST">
      <i class="uil uil-user form-icon"></i> <!-- Person icon from Unicons -->
      <h3>Login CMS Staff</h3>
      <label for="username">Username</label>
      <input type="text" placeholder="Username" name="username" id="username" required>

      <label for="password">Password</label>
      <input type="password" placeholder="Password" name="password" id="password" required>

      <?php
          if (isset($_SESSION['login_error'])) {
              echo '<p class="error">' . htmlspecialchars($_SESSION['login_error']) . '</p>';
              // Unset the error message after displaying it
              unset($_SESSION['login_error']);
          }
      ?>

      <button type="submit">Log In</button><br><br>
      <p>Are you a student? <a href="student.php" class="student-login-link">Login</a></p>
  </form>

  
</body>
</html>

