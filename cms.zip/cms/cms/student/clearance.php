<?php
session_start();
error_reporting(0);
include('connect.php');

// Check if the user is logged in
if (empty($_SESSION['student_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve student ID from session
$studentId = $_SESSION['student_id'];

// Fetch student details based on student ID
$sql = "SELECT clear_id, fullname, faculty, dept FROM clearance_request WHERE clear_id='$studentId'";
$result = $conn->query($sql);
$rowaccess = mysqli_fetch_array($result);

// Fetch clearance request based on student ID
$sql_clearance = "SELECT * FROM clearance_requests WHERE student_id='$studentId' AND status='Complete'";
$result_clearance = $conn->query($sql_clearance);
$clearance = mysqli_fetch_array($result_clearance);

// Set timezone and current date
date_default_timezone_set('Africa/Lagos');
$current_date = date('Y-m-d H:i:s');

// Check if clearance exists
if (!$clearance) {
    die("No clearance request found or not yet approved.");
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clearance Letter</title>

    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet">
    <link href="css/plugins/toastr/toastr.min.css" rel="stylesheet">
    <link href="css/animate.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <style type="text/css">
        table, th, td {
            border: 2px solid black;
        }
        .style1 {
            font-size: xx-large;
            font-weight: bold;
        }
        .style2 {
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="wrapper wrapper-content animated fadeInRight article">
        <div class="row">
            <div class="col-lg-10 col-lg-offset-1">
                <div class="ibox">
                    <div class="ibox-content">
                        <div class="text-center article-title">
                            <p class="text-muted">&nbsp;</p>
                            <h1>UNIVERSITY OF COMPUTING CENTER</h1>
                        </div>
                        <p align="center" class="style1">CLEARANCE LETTER</p>
                        <p>&nbsp;</p>
                        <p>HELLO <?php echo htmlspecialchars($rowaccess['fullname']); ?>,</p>
                        <p>&nbsp;</p>
                        <p align="justify">This is to certify that you have been cleared by the following departments:</p>

                        <table style="width:100%">
                            <tr>
                                <th>LOCATION/SECTION</th>
                                <th>COMMENT</th>
                                <th>DATE</th>
                            </tr>
                            <tr>
                                <td>Branch Academic Coordinator</td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Finance (Administrative Assistance)</td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Cisco Coordinator</td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Workshop</td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>Library Services</td>
                                <td></td>
                                <td></td>
                            </tr>
                        </table>

                        <p align="justify"><strong>Your Details are:</strong></p>
                        <p align="justify"><strong>FULLNAME:</strong> <?php echo htmlspecialchars($rowaccess['fullname']); ?></p>
                        <p align="justify"><strong>REGISTRATION NUMBER:</strong> <?php echo htmlspecialchars($rowaccess['matric_no']); ?></p>
                        <p align="justify"><strong>FACULTY:</strong> <?php echo htmlspecialchars($rowaccess['faculty']); ?></p>
                        <p align="justify"><strong>DEPARTMENT:</strong> <?php echo htmlspecialchars($rowaccess['dept']); ?></p>
                        <p align="justify">&nbsp;</p>
                        <p align="justify">I certify that the above-named student is cleared/not cleared.</p>
                        <p align="left" class="style2">REGISTRATION .....................................................................</p>
                        <p align="right">&nbsp;</p>
                        <p align="left"><strong>SIGNATURE ...........................................................................</strong></p>
                        <hr>
                        <div class="row">
                            <div align="center">
                                <a href="#" id="print-button" onclick="window.print(); return false;">Print this page</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="js/jquery-2.1.1.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>
    <script src="js/inspinia.js"></script>
    <script src="js/plugins/pace/pace.min.js"></script>
</body>

</html>
