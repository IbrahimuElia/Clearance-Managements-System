<?php
session_start();
require_once '../config/conn.php';
$studentId = $_SESSION['student_id']; // Ensure you have the student ID in session
$response = [];

$sql = "SELECT clear_id, status FROM clearance_requests WHERE student_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $studentId);
$stmt->execute();
$result = $stmt->get_result();

while ($row = $result->fetch_assoc()) {
    if ($row['status'] === 'Completed') {
        $response[] = $row['clear_id'];
    }
}

header('Content-Type: application/json');
echo json_encode($response);
?>