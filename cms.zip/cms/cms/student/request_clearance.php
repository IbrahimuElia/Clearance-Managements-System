<?php
require_once '../config/conn.php';

// Collect form data
$student_id = $_POST['student_id'];
$fullname = $_POST['fullname'];
$regno = $_POST['regno'];
$phone = $_POST['phone'];
$branch = $_POST['branch'];
$course = $_POST['course'];
$session_type = $_POST['session_type'];
$clearance_status = $_POST['clearance_status']; // Get clearance_status from hidden input

$response = [];

$conn->begin_transaction();

try {
    // Insert into clearance_request table
    $insertQuery = "INSERT INTO clearance_requests (student_id, full_name, regno, phone, branch, course, session_type) 
                    VALUES (?, ?, ?, ?, ?, ?, ?)";
    if ($stmt = $conn->prepare($insertQuery)) {
        $stmt->bind_param("issssss", $student_id, $fullname, $regno, $phone, $branch, $course, $session_type);
        if (!$stmt->execute()) {
            throw new Exception("Error inserting into clearance_request table: " . $stmt->error);
        }
        $stmt->close();
    } else {
        throw new Exception("Prepare failed for INSERT: " . $conn->error);
    }

    // Update student table
    $updateQuery = "UPDATE students SET clearance_status = ? WHERE student_id = ?";
    if ($stmt = $conn->prepare($updateQuery)) {
        $stmt->bind_param("ii", $clearance_status, $student_id);
        if (!$stmt->execute()) {
            throw new Exception("Error updating student table: " . $stmt->error);
        }
        $stmt->close();
    } else {
        throw new Exception("Prepare failed for UPDATE: " . $conn->error);
    }

    // Commit the transaction
    $conn->commit();

    // Success response
    $response['status'] = 'success';
    $response['message'] = 'Request submitted successfully!';

} catch (Exception $e) {
    // Rollback the transaction if something goes wrong
    $conn->rollback();
    $response['status'] = 'error';
    $response['message'] = 'Failed to complete the operation: ' . $e->getMessage();
}

// Close connection
$conn->close();

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
