<?php if ($clearance_status == 2): ?>



<?php elseif ($clearance_status == 1): ?>
    <div class="status-message">
        <span class="checkmark">&#10003;</span>
        <p>Request submitted. Check status <a href="/cms/student" class="status-link">Here</a>.</p>
    </div>
<?php else: ?>
    <p>Invalid clearance status.</p>
<?php endif; ?>