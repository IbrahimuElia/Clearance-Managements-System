<?php
// Include the FPDF library
require('fpdf/fpdf.php');

// Database connection
require_once '../config/conn.php';
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Validate student ID
if (!isset($_GET['clear_id']) || !is_numeric($_GET['clear_id'])) {
    die("Invalid student ID.");
}

$student_id = $_GET['clear_id'];

// Fetch student data
$query = "SELECT clear_id, student_id, full_name, regno, phone, branch, course, session_type, request_date FROM clearance_requests WHERE clear_id = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $student = $result->fetch_assoc();
} else {
    die("Student not found");
}

// Create a new PDF instance
class PDF extends FPDF {
    // Page header
    function Header() {
        // Set font
        $this->SetFont('Arial', 'B', 12);
        // Title
        $this->Cell(0, 10, 'UNIVERSITY OF DAR ES SALAAM COMPUTING CENTRE:', 0, 1, 'C');
        $this->Cell(0, 10, 'STUDENT CLEARANCE FORM-BRANCHES', 0, 1, 'C');
        $this->Cell(0, 10, 'DIPLOMA/CERTIFICATE IN COMPUTING AND INFORMATION', 0, 1, 'C');
        $this->Cell(0, 10, 'TECHNOLOGY (CCIT/DCIT)', 0, 1, 'C');
        // Line break
        $this->Ln(10);
    }

    // Add student information
    function AddStudentInfo($fullname, $branch, $course, $session, $date) {
        $this->SetFont('Arial', '', 12);
        $this->Cell(40, 10, 'Full Name:', 0, 0);
        $this->Cell(0, 10, $fullname, 0, 1);
        
        $this->Cell(40, 10, 'CENTRE/Branch:', 0, 0);
        $this->Cell(0, 10, $branch, 0, 1);
        
        $this->Cell(40, 10, 'Course:', 0, 0);
        $this->Cell(0, 10, $course, 0, 1);
        
        $this->Cell(40, 10, 'Session:', 0, 0);
        $this->Cell(0, 10, $session, 0, 1);
        
        $this->Cell(40, 10, 'DATE:', 0, 0);
        $this->Cell(0, 10, $date, 0, 1);
        
        $this->Ln(10);
    }

// Add clearance table
function AddClearanceTable() {
    $this->SetFont('Arial', 'B', 12);
    $this->Cell(60, 10, 'LOCATION / SECTION', 1);
    $this->Cell(60, 10, 'COMMENTS', 1);
    $this->Cell(40, 10, 'SIGNATURE', 1);
    $this->Cell(30, 10, 'DATE', 1);
    $this->Ln();

    $this->SetFont('Arial', '', 12);
    
    // Define locations, comments, and fake signatures
    $locations = [
        "Branch Academic Coordinator" => ["Comment: Approved", "Signature: John Doe", "Date: " . date('Y-m-d')],
        "Finance (Administrative Assistant)" => ["Comment: All fees cleared", "Signature: Jane Smith", "Date: " . date('Y-m-d')],
        "Cisco Coordinator" => ["Comment: Training completed", "Signature: Mike Johnson", "Date: " . date('Y-m-d')],
        "Workshop" => ["Comment: Equipment checked", "Signature: Sarah Lee", "Date: " . date('Y-m-d')],
        "Library Services" => ["Comment: No outstanding books", "Signature: Chris Brown", "Date: " . date('Y-m-d')]
    ];

    foreach ($locations as $location => $details) {
        $this->Cell(60, 10, $location, 1);
        $this->Cell(60, 10, $details[0], 1); // Comment
        $this->Cell(40, 10, $details[1], 1); // Fake signature
        $this->Cell(30, 10, $details[2], 1); // Date
        $this->Ln();
    }
}


    // Add training office remarks
    function AddTrainingOfficeRemark() {
        $this->Ln(10);
        $this->Cell(0, 10, 'FOR TRAINING OFFICE REMARK (S) ONLY', 0, 1);
        $this->Cell(0, 10, 'I certify that the above named student is cleared/not cleared.', 0, 1);
        
        $this->Ln(10);
        $this->Cell(40, 10, 'Name:..............................', 0, 0);
        $this->Cell(0, 10, '', 0, 1); // Empty for name
        
        $this->Cell(40, 10, 'Signature:.............................', 0, 0);
        $this->Cell(0, 10, '', 0, 1); // Empty for signature
        
        $this->Cell(40, 10, 'Position: ................................', 0, 0);
        $this->Cell(0, 10, '', 0, 1); // Empty for position
        
        $this->Ln(10);
        $this->SetFont('Arial', 'I', 10);
        $this->Cell(0, 10, 'NB: This FORM should be submitted to Academic office, UCC Dodoma Branch', 0, 1);
    }
}

// Instantiate PDF object
$pdf = new PDF();
$pdf->AddPage();

// Add student information to the PDF
$pdf->AddStudentInfo($student['full_name'], $student['branch'], $student['course'], $student['session_type'], $student['request_date']);

// Add clearance table to the PDF
$pdf->AddClearanceTable();

// Add training office remark section
$pdf->AddTrainingOfficeRemark();

// Output the PDF to the browser (or save it to a file)
$pdf->Output('I', 'student_clearance_form.pdf'); // "I" will display the PDF in the browser

// Close the database connection
$conn->close();
?>
