<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: ../index.php"); // Redirect to login if not logged in
    exit();
}

// Initialize the refresh counter if it doesn't exist
if (!isset($_SESSION['refresh_count'])) {
    $_SESSION['refresh_count'] = 0;
}

// Increment the counter on each refresh
$_SESSION['refresh_count']++;

// Check if the counter has reached 5
if ($_SESSION['refresh_count'] >= 5) {
    $message = "Your Certificate is Ready!";
    // Reset the counter
    $_SESSION['refresh_count'] = 0; // Change this if you want to keep counting
} else {
    $message = ""; // No message until the counter reaches 5
}

require_once '../config/conn.php'; // Include database connection

// Get the user ID from the session
$student_id = $_SESSION['student_id'];

// Prepare SQL statement to fetch user data
$sql = "SELECT fullname, regno, regno, branch, course, session_type, clearance_status FROM students WHERE student_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error preparing the statement: " . $conn->error);
}



$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if student user exists
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $clearance_status = $row['clearance_status']; // Fetch clearance_status
} else {
    echo "No student found with ID $student_id.";
    exit();
}



// Placeholder value; replace with actual student ID retrieval logic
$studentId = $_SESSION['student_id'];

// Fetch student dashboard status
$sql = "SELECT dashboard_status FROM students WHERE student_id = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Prepare failed: " . $conn->error);
}
?>

<html>
<head>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Student - CMS</title> 
    <style>
.tracking-info {
    margin-top: 20px;
}

.tracking-info .title {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 10px;
}

.tracking-content {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
}

.tracking-box {
    flex: 1 1 calc(20% - 20px); /* Adjust width to fit 5 boxes */
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background-color: #f9f9f9;
}

.tracking-box h4 {
    margin: 0 0 10px;
    font-size: 16px;
}

.tracking-box p {
    margin: 0;
    font-size: 14px;
}

/* Style for the status message container */
.status-message {
    display: flex;
    align-items: center;
    background-color: #d4edda; /* Light green background indicating success */
    border: 1px solid #c3e6cb; /* Slightly darker green border */
    border-radius: 4px;
    padding: 10px;
    margin: 10px 0;
    color: #155724; /* Dark green text for success message */
    font-family: Arial, sans-serif;
}

/* Style for the checkmark */
.checkmark {
    font-size: 20px; /* Adjust size as needed */
    color: #28a745; /* Green color for checkmark, representing success */
    margin-right: 10px; /* Space between checkmark and text */
}

/* Style for the paragraph text */
.status-message p {
    margin: 0; /* Remove default margin */
    font-size: 16px; /* Adjust font size as needed */
}

/* Style for the link */
.status-link {
    color: #007bff; /* Blue color for the link to stand out */
    text-decoration: underline; /* Underline the link */
    font-weight: bold; /* Make the link text bold */
}

.status-link:hover {
    color: #0056b3; /* Darker blue when hovered for better UX */
}
.modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 500px;
            border-radius: 8px;
        }

        .close-btn {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close-btn:hover,
        .close-btn:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

       /* Style for the form container */
.dash-content form {
    display: flex;
    flex-direction: column;
    max-width: 800px; /* Increased max-width for a wider form */
    margin: 20px auto;
    padding: 30px;
    background-color: var(--panel-color);
    border-radius: 10px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
    border: 1px solid var(--border-color);
}

/* Grid container for form inputs */
.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr; /* Two columns layout */
    gap: 20px; /* Space between grid items */
    margin-bottom: 20px; /* Space below the grid */
}

/* Style for grid items */
.grid-item {
    display: flex;
    flex-direction: column;
}

/* Style for input fields */
.dash-content form input[type="text"],
.dash-content form select {
    width: 100%;
    padding: 12px;
    margin-bottom: 10px; /* Reduced margin-bottom to fit better within grid */
    border: 1px solid var(--border-color);
    border-radius: 8px;
    background-color: var(--panel-color);
    color: var(--text-color);
    font-size: 16px;
    font-weight: 400;
    outline: none;
    transition: border-color 0.3s ease, background-color 0.3s ease;
}

.dash-content form input[type="text"]:focus,
.dash-content form select:focus {
    border-color: var(--primary-color);
    background-color: var(--box3-color);
}

/* Style for submit button */
.dash-content form button {
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    background-color: var(--primary-color);
    color: var(--panel-color);
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.dash-content form button:hover {
    background-color: #0b3cc1;
    transform: translateY(-2px);
}

.dash-content form button:active {
    transform: translateY(1px);
}

/* Style for labels */
.dash-content form label {
    font-size: 16px;
    font-weight: 500;
    color: var(--text-color);
    margin-bottom: 5px;
    display: block;
}

        /* Popup styles */
        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
            z-index: 1000;
            max-width: 90%;
            box-sizing: border-box;
        }
        .popup.show {
            display: block;
        }
        .popup button {
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            background-color: var(--primary-color);
            color: var(--panel-color);
            cursor: pointer;
        }
        .popup button:hover {
            background-color: #0056b3;
        }

        /* Overlay styles */
        .overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 999;
        }
        .overlay.show {
            display: block;
        }
        .download-button {
            padding: 10px 20px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            margin: 2% 30%;
        }
        .download-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <img src="images/logo.png" alt="">
            </div>

            <span class="logo_name">CMS</span>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="#dashboard">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dashboard</span>
                </a></li>
                <li class="dropdown">
                    <a href="#request-clearance">
                        <i class="uil uil-sync"></i>
                        <span class="link-name">Request Clearance</span>  
                    </a>
                </li>
                <li><a href="#share">
                    <i class="uil uil-share"></i>
                    <span class="link-name">Edit Profile</span>
                </a></li> 
            </ul>
        </div>
    </nav>

    <div class="dashboard">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>

            <div class="search-box">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="Search here...">
            </div>

            
          
            Welcome,<span style="color: blue;"><?php echo htmlspecialchars($row['regno']); ?></span>
    
            

            <div class="profile-menu">
                <img src="images/profile.jpg" alt="" id="profile-img">
                <div class="dropdown-content" id="dropdown-content">
                    <a href="edit-profile.php">Edit Profile</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
        </div>
  

        <section id="dashboard" class="section show">
            <div class="dash-content">
                <div class="tracking-info">
                    <div class="title">
                        <i class="uil uil-location-point"></i>
                        <span class="text">Dashboard (Clearance Status)</span>

                    </div>
                    

                    <div class="tracking-content">
                    <?php

// Get student ID (assumed to be obtained from session or other means)
$studentId = $_SESSION['student_id'];

// Fetch student details and dashboard statuses
$studentId = $_SESSION['student_id'];

// Fetch student details and dashboard statuses, including finance date
$sql = "SELECT s.coordinator_dashboard_status, s.finance_dashboard_status, 
               s.cisco_dashboard_status, s.workshop_dashboard_status, 
               s.librarian_dashboard_status, cr.request_date, 
               s.coordinator_status, cr.finance_date 
        FROM students s
        LEFT JOIN clearance_requests cr ON s.student_id = cr.student_id
        WHERE s.student_id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $studentId);
$stmt->execute();
$result = $stmt->get_result();
$student = $result->fetch_assoc();



echo "<div class='tracking-box'>
<h4>Branch Coordinator</h4>
<p>" . htmlspecialchars($student['coordinator_dashboard_status']) . "</p>
<p>Updated on: " . htmlspecialchars($student['request_date']) . "</p>
</div>";

echo "<div class='tracking-box'>
<h4>Finance</h4>
<p>" . htmlspecialchars($student['finance_dashboard_status']) . "</p>
<p>Updated on: " . htmlspecialchars($student['request_date']) . "</p>
</div>";

echo "<div class='tracking-box'>
<h4>Cisco Coordinator</h4>
<p>" . htmlspecialchars($student['cisco_dashboard_status']) . "</p>
<p>Updated on: " . htmlspecialchars($student['request_date']) . "</p>
</div>";

echo "<div class='tracking-box'>
<h4>Workshop</h4>
<p>" . htmlspecialchars($student['workshop_dashboard_status']) . "</p>
<p>Updated on: " . htmlspecialchars($student['request_date']) . "</p>
</div>";

echo "<div class='tracking-box'>
<h4>Library Services</h4>
<p>" . htmlspecialchars($student['librarian_dashboard_status']) . "</p>
<p>Updated on: " . htmlspecialchars($student['request_date']) . "</p>
</div>";




?>
                    </div>
                </div>

                <div class="activity">
                    <div class="title">
                        <i class="uil uil-clock-three"></i>
                        <span class="text">Recent Activity</span>
                    </div>
                    <div>
                    <div id="clearanceRequests" style="display: none;"></div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        function fetchClearanceRequests() {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", "fetch_clearance_requests.php", true);
            
            xhr.onload = function() {
                if (xhr.status >= 200 && xhr.status < 300) {
                    const response = JSON.parse(xhr.responseText);
                    console.log("Response from server:", response); // Debug log
                    displayDownloadButtons(response);
                } else {
                    console.error("Failed to fetch clearance requests. Status: " + xhr.status);
                }
            };
            
            xhr.onerror = function() {
                console.error("An error occurred while fetching clearance requests.");
            };

            xhr.send();
        }

        function displayDownloadButtons(clearIds) {
    const container = document.getElementById('clearanceRequests');
    container.innerHTML = ''; // Clear previous content

    if (clearIds.length === 0) {
        container.innerHTML = '<p>No completed clearance requests available.</p>';
        container.style.display = 'none'; // Hide if no completed requests
    } else {
        clearIds.forEach(clearId => {
            const button = document.createElement('a');
            button.href = `print.php?clear_id=${encodeURIComponent(clearId)}`;
            button.className = 'download-button';
            button.textContent = 'Download Clearance Form (ID: ' + clearId + ')';
            container.appendChild(button);
        });
        container.style.display = 'block'; // Show the container if there are completed requests
        
        // Display the PHP message after 1 minute (60000 milliseconds)
        setTimeout(() => {
            displayCertificateReadyMessage();
        }, 60000);
    }
}

function displayCertificateReadyMessage() {
    const message = document.createElement('div');
    message.style.color = 'blue';
    message.innerHTML = '<?php echo "Certificate is ready"; ?>'; // PHP message
    document.getElementById('clearanceRequests').appendChild(message);
}


        // Fetch clearance requests on page load
        fetchClearanceRequests();
    });
</script>


                    </div>

                    <?php

// Assuming $studentId is already set

?>
<div class="activity-data">
    <?php 
    // SQL to get the latest clearance request
    $sql = "SELECT status,rejected_status, rejection_reasons, coordinator_comments, finance_comment, total_amount, control_number, debt_items, custom_amount 
            FROM clearance_requests 
            WHERE student_id = ? 
            ORDER BY clear_id DESC 
            LIMIT 1";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $studentId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $request = $result->fetch_assoc();
        $status = $request['status'];
        $rejected_status = $request['rejected_status'];
        $rejectionReasons = $request['rejection_reasons'];
        $coordinatorComments = $request['coordinator_comments'];
        $financeComment = $request['finance_comment'];
        $controlNumber = $request['control_number'];
        $totalAmount = $request['total_amount'];
        $debtItems = json_decode($request['debt_items'], true);
        $customAmounts = json_decode($request['custom_amount'], true); 

        // Display based on the rejection status
        if ($status === 'Coordinator Rejected') {
            echo "<div style='border: 1px solid red; padding: 20px; border-radius: 5px;'>";
            echo "<h2 style='color: red;'>Your request has been rejected by the Coordinator.</h2>";
            echo "<h3>Rejection Reasons:</h3><ul style='list-style-type: disc; margin-left: 20px;'>";
            foreach (explode(',', $rejectionReasons) as $reason) {
                echo "<li>" . htmlspecialchars(trim($reason)) . "</li>";
            }
            echo "</ul>";

            if (!empty($coordinatorComments)) {
                echo "<h3>Coordinator Comments:</h3><p style='border-left: 3px solid red; padding-left: 10px;'>" . nl2br(htmlspecialchars($coordinatorComments)) . "</p>";
            }
            echo '</div>';

            // Reapply form for Coordinator Rejected
            echo '<form action="coordinator_clearance_reapply.php" method="POST" enctype="multipart/form-data" style="margin-top: 20px;">';
            echo '<input type="hidden" name="student_id" value="' . htmlspecialchars($studentId) . '">';
            echo '<input type="hidden" name="rejection_type" value="Coordinator">';
            echo '<div>';
            echo '<label for="reapplyReason">Reason for Reapplication:</label>';
            echo '<input type="text" id="reapplyReason" name="reapplyReason" required>';
            echo '</div>';
            echo '<div>';
            echo '<label for="reapplyFile">Upload Supporting Document (PDF or Image):</label>';
            echo '<input type="file" id="reapplyFile" name="reapplyFile" accept=".pdf, .jpg, .jpeg, .png">';
            echo '</div>';
            echo '<button type="submit">Reapply for Clearance</button>';
            echo '</form>';

        } elseif ($status === 'Finance Rejected') {
            echo "<div style='border: 1px solid orange; padding: 20px; border-radius: 5px;'>";
            echo "<h2 style='color: orange;'>Your request has been rejected by Finance.</h2>";
            
            if (!empty($financeComment)) {
                echo "<h3>Finance Comments:</h3><p style='border-left: 3px solid orange; padding-left: 10px;'>" . nl2br(htmlspecialchars($financeComment)) . "</p>";
            }
            
            echo "<h3>Total Amount Due:</h3><p style='font-weight: bold;'>" . htmlspecialchars($totalAmount) . "</p>";
            
            echo "<h3>Control Number:</h3><p style='font-weight: bold;'>" . htmlspecialchars($controlNumber) . "</p>";
            
            if (!empty($debtItems) && !empty($customAmounts)) {
                echo "<h3>Debt Items:</h3><ul style='list-style-type: disc; margin-left: 20px;'>";
            
                foreach ($debtItems as $index => $item) {
                    // Display debt item
                    echo "<li>" . htmlspecialchars($item);
            
                    // Check if there is a corresponding custom amount
                    if (isset($customAmounts[$index]) && $customAmounts[$index] > 0) {
                        echo " (Fee Amount Debt: Tsh " . htmlspecialchars($customAmounts) . ")";
                        
                    }
                    
                    echo "</li>";
                }
            
                echo "</ul>";
            } elseif (!empty($debtItems)) {
                echo "<h3>Debt Items:</h3><ul style='list-style-type: disc; margin-left: 20px;'>";
                foreach ($debtItems as $item) {
                    echo "<li>" . htmlspecialchars($item) . "</li>";
                }
                echo "</ul>";
            } else {
                echo "<p>No debt items available.</p>";
            }
            
            echo '</div>';
            

            // Reapply form for Finance Rejected
            echo '<form action="finance_clearance_reapply.php" method="POST" enctype="multipart/form-data" style="margin-top: 20px;">';
            echo '<input type="hidden" name="student_id" value="' . htmlspecialchars($studentId) . '">';
            echo '<input type="hidden" name="rejection_type" value="Finance">';
            echo '<div>';
            echo '<label for="finance_reapply_reasons">Reason for Reapplication:</label>';
            echo '<input type="text" id="finance_reapply_reasons" name="finance_reapply_reasons" required>';
            echo '</div>';
            echo '<div>';
            echo '<label for="finance_document">Upload Payment Slip (PDF or Image):</label>';
            echo '<input type="file" id="finance_document" name="finance_document" accept=".pdf, .jpg, .jpeg, .png" >';
            echo '</div>';
            echo '<button type="submit">Reapply for Clearance</button>';
            echo '</form>';

        } elseif ($status === 'Cisco Rejected') {
            $debtItems = json_decode($debtItems, true); // Decode as associative array
            $customAmounts = json_decode($customAmounts, true); // Decode as associative array
            
            echo "<div style='border: 1px solid blue; padding: 20px; border-radius: 5px;'>";
            
            if (!empty($debtItems) && is_array($debtItems) && !empty($customAmounts) && is_array($customAmounts)) {
                echo "<h3>Reason: Finish this Online Module:</h3><ul style='list-style-type: disc; margin-left: 20px;'>";
                
                foreach ($debtItems as $index => $item) {
                    // Display debt item
                    echo "<li>" . htmlspecialchars($item);
                    
                    // Check if there is a corresponding custom amount
                
                    
                    echo "</li>";
                }
                
                echo "</ul>";
            } elseif (!empty($debtItems) && is_array($debtItems)) {
                echo "<h2 style='orange: blue;'>Your request has been rejected by Cisco.</h2>";
                echo "<h3>You have to finish this Module First:</h3><ul style='list-style-type: disc; margin-left: 20px;'>";


                foreach ($debtItems as $item) {
                    echo "<li>" . htmlspecialchars($item) . "</li>";
                }
                echo "</ul>";
            } else {
                echo "<p>No debt items available.</p>";
            }
            
            echo '</div>';

            // Reapply form for Cisco Rejected
            echo '<form action="cisco_clearance_reapply.php" method="POST" enctype="multipart/form-data" style="margin-top: 20px;">';
            echo '<input type="hidden" name="student_id" value="' . htmlspecialchars($studentId) . '">';
            echo '<input type="hidden" name="rejection_type" value="Cisco">';
            echo '<div>';
            echo '<label for="cisco_reapply_reasons">Reason for Reapplication:</label>';
            echo '<input type="text" id="cisco_reapply_reasons" name="cisco_reapply_reasons" required>';
            echo '</div>';
            echo '<div>';
            echo '<label for="reapplyFile">Upload Supporting Document (PDF or Image):</label>';
            echo '<input type="file" id="reapplyFile" name="reapplyFile" accept=".pdf, .jpg, .jpeg, .png">';
            echo '</div>';
            echo '<button type="submit">Reapply for Clearance</button>';
            echo '</form>';
        } elseif ($status === 'Workshop Rejected') {
            $debtItems = json_decode($debtItems, true); // Decode as associative array
            $customAmounts = json_decode($customAmounts, true); // Decode as associative array
            
            echo "<div style='border: 1px solid blue; padding: 20px; border-radius: 5px;'>";
            
            if (!empty($debtItems) && is_array($debtItems) && !empty($customAmounts) && is_array($customAmounts)) {
                echo "<h3>Reason: Finish this Online Module:</h3><ul style='list-style-type: disc; margin-left: 20px;'>";
                
                foreach ($debtItems as $index => $item) {
                    // Display debt item
                    echo "<li>" . htmlspecialchars($item);
                    
                    // Check if there is a corresponding custom amount
                    if (isset($customAmounts[$index]) && $customAmounts[$index] > 0) {
                        echo " (Fee Amount Debt: Tsh " . htmlspecialchars($customAmounts[$index]) . ")";
                    }
                    
                    echo "</li>";
                }
                
                echo "</ul>";
            } elseif (!empty($debtItems) && is_array($debtItems)) {
                echo "<h2 style='orange: blue;'>Your request has been rejected by Workshop.</h2>";
                echo "<h3>You have to return this items </h3><ul style='list-style-type: disc; margin-left: 20px;'>";


                foreach ($debtItems as $item) {
                    echo "<li>" . htmlspecialchars($item) . "</li>";
                }
                echo "</ul>";
            } else {
                echo "<p>No debt items available.</p>";
            }
            
            echo '</div>';

            // Reapply form for Cisco Rejected
            echo '<form action="workshop_clearance_reapply.php" method="POST" enctype="multipart/form-data" style="margin-top: 20px;">';
            echo '<input type="hidden" name="student_id" value="' . htmlspecialchars($studentId) . '">';
            echo '<input type="hidden" name="rejection_type" value="Cisco">';
            echo '<div>';
            echo '<label for="workshop_reapply_reasons">Reason for Reapplication:</label>';
            echo '<input type="text" id="cisco_reapply_reasons" name="cisco_reapply_reasons" required>';
            echo '</div>';
            echo '<div>';
            echo '<label for="reapplyFile">Upload Supporting Document (PDF or Image):</label>';
            echo '<input type="file" id="reapplyFile" name="reapplyFile" accept=".pdf, .jpg, .jpeg, .png">';
            echo '</div>';
            echo '<button type="submit">Reapply for Clearance</button>';
            echo '</form>';
        } 
        elseif ($status === 'Librarian Rejected') {
            $debtItems = json_decode($debtItems, true); // Decode as associative array
            $customAmounts = json_decode($customAmounts, true); // Decode as associative array
            
            echo "<div style='border: 1px solid blue; padding: 20px; border-radius: 5px;'>";
            
            if (!empty($debtItems) && is_array($debtItems) && !empty($customAmounts) && is_array($customAmounts)) {
                echo "<h3>Reason: Finish this Online Module:</h3><ul style='list-style-type: disc; margin-left: 20px;'>";
                
                foreach ($debtItems as $index => $item) {
                    // Display debt item
                    echo "<li>" . htmlspecialchars($item);
                    
                    // Check if there is a corresponding custom amount
                    if (isset($customAmounts[$index]) && $customAmounts[$index] > 0) {
                    }
                    
                    echo "</li>";
                }
                
                echo "</ul>";
            } elseif (!empty($debtItems) && is_array($debtItems)) {
                echo "<h2 style='orange: blue;'>Your request has been rejected by Workshop.</h2>";
                echo "<h3>You have to return this items </h3><ul style='list-style-type: disc; margin-left: 20px;'>";


                foreach ($debtItems as $item) {
                    echo "<li>" . htmlspecialchars($item) . "</li>";
                }
                echo "</ul>";
            } else {
                echo "<p>No debt items available.</p>";
            }
            
            echo '</div>';

            // Reapply form for Cisco Rejected
            echo '<form action="librarian_clearance_reapply.php" method="POST" enctype="multipart/form-data" style="margin-top: 20px;">';
            echo '<input type="hidden" name="student_id" value="' . htmlspecialchars($studentId) . '">';
            echo '<input type="hidden" name="rejection_type" value="Cisco">';
            echo '<div>';
            echo '<label for="workshop_reapply_reasons">Reason for Reapplication:</label>';
            echo '<input type="text" id="workshop_reapply_reasons" name="workshop_reapply_reasons" required>';
            echo '</div>';
            echo '<div>';
            echo '<label for="reapplyFile">Upload Supporting Document (PDF or Image):</label>';
            echo '<input type="file" id="reapplyFile" name="reapplyFile" accept=".pdf, .jpg, .jpeg, .png">';
            echo '</div>';
            echo '<button type="submit">Reapply for Clearance</button>';
            echo '</form>';
        } 

        
        else {
            echo "<h1>Request status: " . htmlspecialchars($status) . "</h1>";
        }
        
    } else {
        echo "<h2>No clearance request found.</h2>";
    }
    ?>
</div>

                <div>
                               <div>
    <?php if (!empty($message)): ?>
        <div style="color: blue; font-weight: bold; background-color: green; padding: 10px; border-radius: 5px;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>
</div>
                </div>

<!-- Modal for Success Message -->
<div id="successModal" style="display: none; position: fixed; top: 50%; left: 50%; transform: translate(-50%, -50%); background-color: white; padding: 20px; border: 2px solid green; z-index: 1000;">
    <h3>Success</h3>
    <p id="modalMessage"></p>
    <button onclick="closeModal()">Close</button>
</div>
<div id="overlay" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0, 0, 0, 0.7); z-index: 999;"></div>

<script>
function showModal(message) {
    document.getElementById('modalMessage').textContent = message;
    document.getElementById('successModal').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

function closeModal() {
    document.getElementById('successModal').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}
</script>

        </section>

        <section id="request-clearance" class="section">
            <div class="dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="uil uil-tachometer-fast-alt"></i>
                        <span class="text">Request Clearance</span>
                    </div>

                    <div class="boxes">
                        <div class="form-container">
                            <?php if ($clearance_status == 0): ?>
                                <!-- Display the form -->
                                <form id="myForm" method="POST" action="request_clearance.php">
    <input type="hidden" name="student_id" value="<?php echo htmlspecialchars($student_id); ?>">

    <div class="form-grid">
        <div class="grid-item">
            <label for="fullname">Full Name:</label>
            <input type="text" name="fullname" id="fullname" value="<?php echo htmlspecialchars($row['fullname']); ?>" required>
        </div>

        <div class="grid-item">
            <label for="regno">Registration No:</label>
            <input type="text" name="regno" id="regno" value="<?php echo htmlspecialchars($row['regno']); ?>" readonly required>
        </div>

        <div class="grid-item">
            <label for="phone">Phone Number:</label>
            <input type="text" name="phone" id="phone" required>
        </div>

        <div class="grid-item">
            <label for="branch">Branch:</label>
            <select name="branch" id="branch" required>
                <option value="" disabled>Select Branch</option>
                <option value="Dodoma" <?php echo $row['branch'] == 'Dodoma' ? 'selected' : ''; ?>>Dodoma</option>
                <option value="Dar es Salaam" <?php echo $row['branch'] == 'Dar es Salaam' ? 'selected' : ''; ?>>Dar es Salaam</option>
            </select>
        </div>

        <div class="grid-item">
            <label for="course">Course:</label>
            <select name="course" id="course" required>
                <option value="" disabled>Select course</option>
                <option value="DCIT" <?php echo $row['course'] == 'DCIT' ? 'selected' : ''; ?>>DCIT</option>
                <option value="CCIT" <?php echo $row['course'] == 'CCIT' ? 'selected' : ''; ?>>CCIT</option>
            </select>
        </div>

        <div class="grid-item">
            <label for="session_type">Session:</label>
            <select name="session_type" id="session_type" required>
                <option value="" disabled>Select Session</option>
                <option value="Morning" <?php echo $row['session_type'] == 'Morning' ? 'selected' : ''; ?>>Morning</option>
                <option value="Evening" <?php echo $row['session_type'] == 'Evening' ? 'selected' : ''; ?>>Evening</option>
            </select>
        </div>
    </div>

    <input type="hidden" name="clearance_status" id="clearance_status" value="2">
    <button type="submit">Request Now</button>
</form>
<div id="popup" class="popup">
        <p id="popupMessage"></p>
        <button id="closePopupButton">Close</button>
    </div>
    <div id="overlay" class="overlay"></div>

    <script>
        document.getElementById('myForm').addEventListener('submit', function(e) {
            e.preventDefault(); // Prevent the default form submission

            var formData = new FormData(this);

            fetch('request_clearance.php', { // Replace with the path to your PHP script
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                var popup = document.getElementById('popup');
                var overlay = document.getElementById('overlay');
                var popupMessage = document.getElementById('popupMessage');
                var closePopupButton = document.getElementById('closePopupButton');

                popupMessage.textContent = data.message;
                popup.classList.add('show');
                overlay.classList.add('show');

                // Close button handler to refresh the page
                closePopupButton.onclick = function() {
                    popup.classList.remove('show');
                    overlay.classList.remove('show');
                    setTimeout(function() {
                        window.location.reload(); // Refresh the page
                    }, 500); // Delay before refreshing
                };

                // Optionally, refresh the page automatically after a delay
                if (data.status === 'success') {
                    setTimeout(function() {
                        window.location.reload(); // Refresh the page after 3 seconds
                    }, 3000); // Adjust the delay as needed
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    </script>

                                <?php elseif ($clearance_status == 2): ?>
    <div class="status-message">
        <span class="checkmark">&#10003;</span>
        <p>Request submitted. Check status <a href="/cms/student" class="status-link">Here</a>.</p>
    </div>
<?php else: ?>
    <p>Invalid clearance status.</p>
<?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
            <script>
            document.addEventListener('DOMContentLoaded', () => {
                const urlParams = new URLSearchParams(window.location.search);
                const success = urlParams.get('success');

                if (success === '1') {
                    // Show success message modal
                    const modal = document.getElementById('success-modal');
                    modal.style.display = 'block';

                    // Close the modal when clicking on the close button
                    document.querySelector('.close-btn').addEventListener('click', () => {
                        modal.style.display = 'none';
                    });

                    // Close the modal when clicking anywhere outside the modal
                    window.addEventListener('click', (event) => {
                        if (event.target === modal) {
                            modal.style.display = 'none';
                        }
                    });
                }
            });
        </script>

        </section>
    </div>
    
    <script>
        const sections = document.querySelectorAll('.section');
        const navLinks = document.querySelectorAll('nav a');

        navLinks.forEach(link => {
            link.addEventListener('click', (event) => {
                event.preventDefault();
                const targetSection = document.getElementById(link.hash.substr(1));

                sections.forEach(section => {
                    section.classList.remove('show');
                });

                targetSection.classList.add('show');
            });
        });
    </script>
    <script>
        document.getElementById('myInput').addEventListener('input', function (e) {
            let value = e.target.value;

            // Remove all non-digit characters
            value = value.replace(/\D/g, '');

            // Format the value to match the desired pattern
            if (value.length > 2) {
                value = value.slice(0, 2) + '-' + value.slice(2);
            }
            if (value.length > 6) {
                value = value.slice(0, 7) + '-' + value.slice(7);
            }
            if (value.length > 9) {
                value = value.slice(0, 10) + '-' + value.slice(10, 15); // Allow only 5 digits in the last segment
            }

            // Set the formatted value back to the input
            e.target.value = value;
        });
    </script>
</body>
</html>
