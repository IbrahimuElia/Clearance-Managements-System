<?php
require_once '../config/conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['student_id'])) {
    $studentId = intval($_POST['student_id']);

    // Initialize a variable to hold the destination path
    $destPath = '';

    // Handle file upload
    if (isset($_FILES['finance_document']) && $_FILES['finance_document']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['finance_document']['tmp_name'];
        $fileName = $_FILES['finance_document']['name'];
        $fileType = $_FILES['finance_document']['type'];

        // Set allowed file types
        $allowedFileTypes = ['application/pdf', 'image/jpeg', 'image/png'];

        if (in_array($fileType, $allowedFileTypes)) {
            $uploadFileDir = '../uploads/coordinatorReapply/';
            $destPath = $uploadFileDir . basename($fileName);

            // Ensure directory exists and is writable
            if (!is_dir($uploadFileDir) || !is_writable($uploadFileDir)) {
                echo json_encode(['error' => 'Upload directory is not writable.']);
                exit;
            }

            // Move the file to the upload directory
            if (move_uploaded_file($fileTmpPath, $destPath)) {
                // File uploaded successfully, now update the database
                $stmt = $conn->prepare("UPDATE clearance_requests SET workshop_reapply_reasons = ?, finance_document = ?, status = 'Processing Workshop Reapply', workshop_view_reject = 'Yes', rejected_status = 'Rejected Workshop' WHERE student_id = ?");
                
                if ($stmt === false) {
                    echo json_encode(['error' => 'Prepare failed: ' . $conn->error]);
                    exit;
                }

                $stmt->bind_param("ssi", $reapplyReason, $destPath, $studentId);
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'There was an error moving the uploaded file.']);
                exit;
            }
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid file type. Only PDF and image files are allowed.']);
            exit;
        }
    }

    // If no file is uploaded, still update the database without the file path
    if (empty($destPath)) {
        $stmt = $conn->prepare("UPDATE clearance_requests SET workshop_reapply_reasons = ?, status = 'Processing Workshop Reapply', workshop_view_reject = 'Yes', rejected_status = 'Rejected Workshop' WHERE student_id = ?");
        
        if ($stmt === false) {
            echo json_encode(['error' => 'Prepare failed: ' . $conn->error]);
            exit;
        }

        $stmt->bind_param("si", $reapplyReason, $studentId);
    }

    // Execute the statement
    if ($stmt->execute()) {
        $message = !empty($destPath) ? 'Reapplication submitted successfully with file.' : 'Reapplication submitted successfully without file.';
        echo json_encode(['success' => $message]);
    } else {
        http_response_code(400);
        echo json_encode(['error' => 'Failed to submit reapplication.']);
    }

    // Close statement
    $stmt->close();
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request.']);
}

// Close the database connection
$conn->close();
?>
