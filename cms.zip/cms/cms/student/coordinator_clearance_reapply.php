<?php
require_once '../config/conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['student_id'])) {
    $studentId = intval($_POST['student_id']);
    $reapplyReason = $_POST['reapplyReason'];

    // Check if a file was uploaded
    if (isset($_FILES['reapplyFile']) && $_FILES['reapplyFile']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['reapplyFile']['tmp_name'];
        $fileName = $_FILES['reapplyFile']['name'];
        $fileType = $_FILES['reapplyFile']['type'];

        // Set allowed file types
        $allowedFileTypes = ['application/pdf', 'image/jpeg', 'image/png'];

        if (in_array($fileType, $allowedFileTypes)) {
            $uploadFileDir = '../uploads/coordinatorReapply/';
            $destPath = $uploadFileDir . basename($fileName);

            // Ensure directory exists and is writable
            if (!is_dir($uploadFileDir) || !is_writable($uploadFileDir)) {
                echo json_encode(['error' => 'Upload directory is not writable.']);
                exit;
            }

            // Move the file to the upload directory
            if (move_uploaded_file($fileTmpPath, $destPath)) {
                // Update reapplication data in the database
                $stmt = $conn->prepare("UPDATE clearance_requests SET reapplyreason = ?, coordinator_document_path = ?, status = 'Processing Reapply', rejected_status = 'Rejected Coordinator Reapply', coordinater_view_reject = 'Yes' WHERE student_id = ?");
                if ($stmt === false) {
                    echo json_encode(['error' => 'Prepare failed: ' . $conn->error]);
                    exit;
                }

                $stmt->bind_param("ssi", $reapplyReason, $destPath, $studentId);

                if ($stmt->execute()) {
                    echo json_encode(['success' => 'Reapplication submitted successfully.']);
                } else {
                    http_response_code(400);
                    echo json_encode(['error' => 'Failed to submit reapplication.']);
                }
            } else {
                http_response_code(400);
                echo json_encode(['error' => 'There was an error moving the uploaded file.']);
            }
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid file type. Only PDF and image files are allowed.']);
        }
    } else {
        // If no file is uploaded, still update the database without the file path
        $stmt = $conn->prepare("UPDATE clearance_requests SET reapplyreason = ?, status = 'Processing Reapply', rejected_status = 'Rejected Coordinator Reapply', coordinater_view_reject = 'Yes' WHERE student_id = ?");
        if ($stmt === false) {
            echo json_encode(['error' => 'Prepare failed: ' . $conn->error]);
            exit;
        }

        $stmt->bind_param("si", $reapplyReason, $studentId);

        if ($stmt->execute()) {
            echo json_encode(['success' => 'Reapplication submitted successfully without file.']);
        } else {
            http_response_code(400);
            echo json_encode(['error' => 'Failed to submit reapplication without file.']);
        }
    }
} else {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request.']);
}

$conn->close();
?>
