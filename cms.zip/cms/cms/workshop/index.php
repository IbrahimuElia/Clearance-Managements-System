<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /cms"); // Redirect to login if not logged in
    exit();
}

require_once '../config/conn.php'; // Ensure this path is correct

$sql = "SELECT * FROM clearance_requests WHERE status = 'Pending Workshop Approval' ORDER BY request_date DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Workshop - CMS</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>/* Custom CSS for forms */
.dash-content form {
    display: flex;
    flex-direction: column;
    max-width: 800px; /* Increased max-width for a wider form */
    margin: 20px auto;
    padding: 30px;
    background-color: var(--panel-color);
    border-radius: 10px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
    border: 1px solid var(--border-color);
}

/* Grid container for form inputs */
.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr; /* Two columns layout */
    gap: 20px; /* Space between grid items */
    margin-bottom: 20px; /* Space below the grid */
}

/* Style for grid items */
.grid-item {
    display: flex;
    flex-direction: column;
}

/* Style for input fields */
.dash-content form input[type="text"],
.dash-content form select {
    width: 100%;
    padding: 12px;
    margin-bottom: 10px; /* Reduced margin-bottom to fit better within grid */
    border: 1px solid var(--border-color);
    border-radius: 8px;
    background-color: var(--panel-color);
    color: var(--text-color);
    font-size: 16px;
    font-weight: 400;
    outline: none;
    transition: border-color 0.3s ease, background-color 0.3s ease;
}

.dash-content form input[type="text"]:focus,
.dash-content form select:focus {
    border-color: var(--primary-color);
    background-color: var(--box3-color);
}

/* Style for submit button */
.dash-content form button {
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    background-color: var(--primary-color);
    color: var(--panel-color);
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.dash-content form button:hover {
    background-color: #0b3cc1;
    transform: translateY(-2px);
}

.dash-content form button:active {
    transform: translateY(1px);
}

/* Style for labels */
.dash-content form label {
    font-size: 16px;
    font-weight: 500;
    color: var(--text-color);
    margin-bottom: 5px;
    display: block;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    margin: 0;
    padding: 0;
}

* {
    box-sizing: border-box;
}

.open-button {
    background-color: #555;
    color: white;
    padding: 16px 20px;
    border: none;
    cursor: pointer;
    opacity: 0.8;
    position: fixed;
    bottom: 23px;
    right: 28px;
    width: 280px;
    font-size: 16px;
    font-weight: 500;
    transition: background-color 0.3s;
}

.open-button:hover {
    background-color: #0b3cc1;
    opacity: 1;
}

.form-popup {
    display: none;
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    border: 3px solid #f1f1f1;
    background-color: white;
    z-index: 9;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    max-width: 400px;
    width: 100%;
    padding: 20px;
}

.form-container {
    display: flex;
    flex-direction: column;
}

.form-container .section {
    display: none;
}

.form-container .active {
    display: block;
}

.form-container input[type=text], 
.form-container input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    border: 1px solid #ddd;
    border-radius: 5px;
    background: #f1f1f1;
}

.form-container input[type=text]:focus, 
.form-container input[type=password]:focus {
    background-color: #ddd;
    outline: none;
}

.section-buttons {
    display: flex;
    justify-content: space-between; /* Space out the buttons */
    gap: 10px; /* Space between buttons */
    margin-top: 10px; /* Space above buttons */
}

.btn, .approve-btn {
    padding: 12px 20px;
    border: none;
    cursor: pointer;
    font-size: 14px; /* Smaller font size for better fit */
    font-weight: 500;
    border-radius: 5px;
    transition: background-color 0.3s, transform 0.3s;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 1; /* Allow buttons to grow and fit the container */
}

.btn {
    background-color: #04AA6D;
    color: white;
}

.btn:hover {
    background-color: #0b3cc1;
}

.btn.cancel {
    background-color: red;
}

.btn.cancel:hover {
    background-color: darkred;
}

.approve-btn {
    background-color: #0056b3; /* Dark blue background */
    color: white;
}

.approve-btn:hover {
    background-color: #004494; /* Darker blue on hover */
    transform: scale(1.05); /* Slightly enlarge the button */
}

.approve-btn:active {
    background-color: #003366; /* Even darker blue on click */
    transform: scale(0.98); /* Slightly shrink the button on click */
}

#checkboxContainer {
    display: flex;
    flex-direction: column;
    margin-top: 20px;
}

#checkboxContainer label {
    margin: 5px 0;
    display: flex;
    align-items: center;
    font-size: 16px;
}

#checkboxContainer input[type=checkbox] {
    margin-right: 10px;
    transform: scale(1.2);
}

</style>
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <img src="images/logo.png" alt="Logo">
            </div>
            <span class="logo_name">CMS</span>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="#dashboard">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dashboard</span>
                </a></li>
                <!-- <li>
                    <a href="#message">
                        <i class="uil uil-message"></i>
                        <span class="link-name">Message</span>
                    </a>
                </li> -->
                <li>
                    <a href="#user">
                        <i class="uil uil-user"></i>
                        <span class="link-name">View Users</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="dashboard">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>
            <div class="search-box">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="Search here...">
            </div>
            <?php echo "Welcome, " . htmlspecialchars($_SESSION['username']) . "!"; ?>
            <div class="profile-menu">
                <img src="images/profile.jpg" alt="Profile Image" id="profile-img">
                <div class="dropdown-content" id="dropdown-content">
                    <a href="edit-profile.php">Edit Profile</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
        </div>

        <section id="dashboard" class="section show">
            <div class="dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="uil uil-tachometer-fast-alt"></i>
                        <span class="text">Dashboard</span>
                    </div>
                    <!-- <div class="boxes">
                        <div class="box box1">
                            <i class="uil uil-thumbs-up"></i>
                            <span class="text">Total Likes</span>
                            <span class="number">50,120</span>
                        </div>
                        <div class="box box2">
                            <i class="uil uil-comments"></i>
                            <span class="text">Comments</span>
                            <span class="number">20,120</span>
                        </div>
                        <div class="box box3">
                            <i class="uil uil-share"></i>
                            <span class="text">Total Share</span>
                            <span class="number">10,120</span>
                        </div>
                    </div> -->
                </div>
                <div class="activity">
                    <div class="title">
                        <i class="uil uil-clock-three"></i>
                        <span class="text">Pending Clearance</span>
                    </div>
                    <?php
                 if ($result->num_rows > 0) {
                        echo "<table style='width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8f9fa; color: #343a40;'>
                                <thead style='background-color: #007bff; color: #ffffff;'>
                                    <tr>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Full Name</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Registration No</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Branch</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Course</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Session</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Clearance Date</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Action</th>
                                    </tr>
                                </thead>
                                <tbody>";

                        while ($row = $result->fetch_assoc()) {
                            echo "<tr style='background-color: #ffffff;'>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['full_name']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['regno']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['branch']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['course']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['session_type']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['request_date']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'><a href='#'class='view-details' data-id='{$row['clear_id']}' style='display: inline-block; padding: 8px 16px; font-size: 14px; font-weight: bold; color: #ffffff; background-color: #007bff; border: none; border-radius: 5px; text-decoration: none; text-align: center; cursor: pointer; transition: background-color 0.3s ease;'>View</a></td>
                                  </tr>";
                        }
                        echo "</tbody>
                            </table>";
                    } else {
                        echo "<p>No requests pending approval.</p>";
                    }
                    ?>
<div class="form-popup" id="myForm">
  <form class="form-container">
    <div class="section" id="noDebtSection">
      <h1>No Debt</h1>
      <p>You have no debts to manage at the moment.</p>
      <div class="section-buttons">
        <button type="button" class="approve-btn" id="approveBtn">Approve</button>
        <button type="button" class="btn" onclick="showCheckDebt()">Reject</button>
        <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
      </div>
    </div>
    
    <div class="section" id="checkDebtSection">
      <h1>Check Cisco CCNA1 AND CCNA2</h1>
      <p>Click approve if Student finished the course, otherwise Reject:</p>
      <div id="checkboxContainer">
    <!-- Add checkboxes for debt items here -->
    <label><input type="checkbox" name="debtItem[]" value="RAM">RAM</label>
    <label><input type="checkbox" name="debtItem[]" value="Hard Disk"> Hard Disk</label>
    <label><input type="checkbox" name="debtItem[]" value="Mouse">Mouse</label>
    <label><input type="checkbox" name="debtItem[]" value="Wireless Adapter">Wireless Adapter</label>
</div>
      <div class="section-buttons">
        <button type="button" class="btn" onclick="sendDebt()">Reject</button>
        <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
      </div>
    </div>
  </form>
</div>

<div class="activity">
                    <div class="title">
                        <i class="uil uil-clock-three"></i>
                        <span class="text">Pending Clearance</span>
                    </div>
                    <?php
  $sql = "SELECT * FROM clearance_requests WHERE workshop_view_reject = 'Yes' ORDER BY request_date DESC";
  $result = $conn->query($sql);                       if ($result->num_rows > 0) {
                        echo "<table style='width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8f9fa; color: #343a40;'>
                                <thead style='background-color: #007bff; color: #ffffff;'>
                                    <tr>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Full Name</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Registration No</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Branch</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Course</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Session</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Reapply Reasons</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Clearance Date</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Action</th>
                                    </tr>
                                </thead>
                                <tbody>";

                        while ($row = $result->fetch_assoc()) {
                            echo "<tr style='background-color: #ffffff;'>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['full_name']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['regno']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['branch']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['course']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['session_type']}</td>
                                     <td style='padding: 12px; border: 1px solid #dee2e6;'>";

        if (!empty($debt_Items)) {
            echo "<h3 style='margin: 0;'>Debt Items:</h3><ul style='list-style-type: disc; margin-left: 20px;'>";
            foreach ($debt_Items as $item) {
                echo "<li>" . htmlspecialchars($debt_item) . "</li>";
            }
            echo "</ul>";
        } else {
            echo "No debt items.";
        }

        echo "</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['request_date']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'><a href='#'class='view-details' data-id='{$row['clear_id']}' style='display: inline-block; padding: 8px 16px; font-size: 14px; font-weight: bold; color: #ffffff; background-color: #007bff; border: none; border-radius: 5px; text-decoration: none; text-align: center; cursor: pointer; transition: background-color 0.3s ease;'>View</a></td>
                                  </tr>";
                        }
                        echo "</tbody>
                            </table>";
                    } else {
                        echo "<p>No requests pending approval.</p>";
                    }
                    ?>
                </div>


                <script>
let currentClearId = null;

document.addEventListener('DOMContentLoaded', function () {
    const viewButtons = document.querySelectorAll('.view-details');

    viewButtons.forEach(button => {
        button.addEventListener('click', function () {
            currentClearId = this.getAttribute('data-id');
            openForm();
        });
    });
});

function openForm() {
    document.getElementById("myForm").style.display = "block";
    showNoDebt(); // Show no debt section when the form opens
}

function closeForm() {
    document.getElementById("myForm").style.display = "none";
}

function showNoDebt() {
    document.getElementById("noDebtSection").style.display = "block";
    document.getElementById("checkDebtSection").style.display = "none";
}

function showCheckDebt() {
    document.getElementById("noDebtSection").style.display = "none";
    document.getElementById("checkDebtSection").style.display = "block";
}

function sendDebt() {
    const checkedItems = Array.from(document.querySelectorAll('#checkboxContainer input[type=checkbox]:checked'))
                              .map(checkbox => checkbox.value);
    
    if (checkedItems.length > 0) {
        const data = new URLSearchParams({
            clear_id: currentClearId,
            debt_items: JSON.stringify(checkedItems),
            reject: "true" // Indicate rejection
        });

        sendRequest(data.toString(), "handle_workshop_approval.php", "Request processed successfully.");
    } else {
        alert('Please select at least one item to reject.');
    }
}

document.getElementById('approveBtn').addEventListener('click', function() {
    if (currentClearId) {
        const data = new URLSearchParams({
            clear_id: currentClearId,
            approve: "true",
        });

        sendRequest(data.toString(), "handle_workshop_approval.php", "Approval processed successfully.");
    } else {
        showModal("No request ID found.");
    }
});

function sendRequest(data, url, successMessage) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", url, true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
            showModal(successMessage);
        } else {
            showModal("Failed to process request: " + xhr.statusText);
        }
    };

    xhr.onerror = function() {
        showModal("An error occurred while processing your request.");
    };

    xhr.send(data);
    closeForm(); // Close the form after sending
}

function showModal(message) {
    alert(message); // You can replace this with a modal implementation if needed
}
</script>

<!-- Modal HTML -->
<div id="responseModal" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); width:300px; background-color:white; border:1px solid #ddd; border-radius:5px; box-shadow:0px 0px 10px rgba(0,0,0,0.2); z-index:1000;">
    <div style="padding:20px;">
        <span id="modalMessage"></span>
        <button onclick="closeModal()" style="display:block; margin-top:10px; padding:10px; background-color:#007bff; color:white; border:none; border-radius:5px; cursor:pointer;">Close</button>
    </div>
</div>

<!-- Overlay for Modal -->
<div id="overlay" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:999;"></div>


        </section><section id="register-staff" class="section">
            <div class="dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="uil uil-tachometer-fast-alt"></i>
                        <span class="text">Register Staff</span>
                    </div>
                    <div class="boxes">
                        <div class="form-container">
                            <form method="POST" action="register_staff.php">
                                <div class="form-grid">
                                    <div class="grid-item">
                                        <label for="firstname">First Name:</label>
                                        <input type="text" name="firstname" id="firstname" placeholder="First Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="lastname">Last Name:</label>
                                        <input type="text" name="lastname" id="lastname" placeholder="Last Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="email">Email:</label>
                                        <input type="email" name="email" id="email" placeholder="Email" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="password">Password:</label>
                                        <input type="password" name="password" id="password" placeholder="Password" required>
                                    </div>
                                </div>
                                <button type="submit">Register</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section><section id="register-student" class="section">
            <div class="dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="uil uil-tachometer-fast-alt"></i>
                        <span class="text">Register Student</span>
                    </div>
                    <div class="boxes">
                        <div class="form-container">
                            <form method="POST" action="register_student.php">
                                <div class="form-grid">
                                    <div class="grid-item">
                                        <label for="firstname">First Name:</label>
                                        <input type="text" name="firstname" id="firstname" placeholder="First Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="lastname">Last Name:</label>
                                        <input type="text" name="lastname" id="lastname" placeholder="Last Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="regno">Reg No:</label>
                                        <input type="text" name="regno" id="regno" placeholder="Reg No" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="email">Email:</label>
                                        <input type="email" name="email" id="email" placeholder="Email" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="password">Password:</label>
                                        <input type="password" name="password" id="password" placeholder="Password" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="branch">Branch:</label>
                                        <select name="branch" id="branch" required>
                                            <option value="" disabled selected>Select Branch</option>
                                            <option value="Dodoma Branch">Dodoma Branch</option>
                                            <option value="Dar es Salaam Main Branch">Dar es Salaam (Main)</option>
                                            <option value="Mbeya Branch">Mbeya Branch</option>
                                        </select>
                                    </div>
                                    <div class="grid-item">
                                        <label for="course">Course:</label>
                                        <select name="course" id="course" required>
                                            <option value="" disabled selected>Select Course</option>
                                            <option value="DCIT">Diploma in Information Communication Technology</option>
                                            <option value="DBIT">Diploma in Business Information Technology</option>
                                        </select>
                                    </div>
                                    <div class="grid-item">
                                        <label for="session_type">Session:</label>
                                        <select name="session_type" id="session_type" required>
                                            <option value="" disabled selected>Select Session</option>
                                            <option value="Morning">Morning</option>
                                            <option value="Evening">Evening</option>
                                        </select>
                                    </div>
                                </div>
                                <button type="submit">Register Student</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section><script>
            // JavaScript to handle navigation between sections
            const sections = document.querySelectorAll('.section');
            const navLinks = document.querySelectorAll('nav a');

            navLinks.forEach(link => {
                link.addEventListener('click', (event) => {
                    event.preventDefault();
                    const targetSection = document.getElementById(link.hash.substr(1));

                    sections.forEach(section => {
                        section.classList.remove('show');
                    });

                    targetSection.classList.add('show');
                });
            });

            // JavaScript to fetch and display student details
            document.addEventListener("DOMContentLoaded", function() {
                document.querySelectorAll('.view-details').forEach(link => {
                    link.addEventListener('click', function(event) {
                        event.preventDefault();
                        const id = this.getAttribute('data-id');
                        fetchStudentDetails(id);
                    });
                });
            });

            function fetchStudentDetails(id) {
                fetch(`handle_workshop_approval.php?id=${id}`)
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('student-details').innerHTML = data;
                    })
                    .catch(error => console.error('Error fetching student details:', error));
            }
        </script>
    </div>
</body>
</html>
