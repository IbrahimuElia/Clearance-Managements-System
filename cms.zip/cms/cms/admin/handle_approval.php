<?php

require_once '../config/conn.php';
// Get form data
$requestId = intval($_POST['clear_id']);
$approve = isset($_POST['approve']);
$reject = isset($_POST['reject']);

// Prepare to update request status and dashboard status
if ($approve && !$reject) {
    $status = 'Pending Finance Approval';
    $stmt = $conn->prepare("UPDATE clearance_requests SET status = ?, rejected_status = 'Approved', coordinater_view_reject = 'Nothing' WHERE clear_id = ?");
    $stmt->bind_param("si", $status, $requestId);
    
    if ($stmt->execute()) {
        // Additional logic here
    } else {
        echo "Error updating request status: " . $stmt->error;
    }
    
    if ($stmt->execute()) {
        // Update the dashboard status
        $studentId = (int)$conn->query("SELECT student_id FROM clearance_requests WHERE clear_id = $requestId")->fetch_assoc()['student_id'];
        $dashboardStatus = 'Coordinator Approved';
        $stmt = $conn->prepare("UPDATE students SET coordinator_dashboard_status = ? WHERE student_id = ?");
        $stmt->bind_param("si", $dashboardStatus, $studentId);
        $stmt->execute();
        
        echo "Request approved by Coordinator and student dashboard status updated.";
    } else {
        echo "Error: " . $stmt->error;
    }
} elseif ($reject && !$approve) {
    $status = 'Rejected';
    $stmt = $conn->prepare("UPDATE clearance_requests SET status = ? WHERE clear_id = ?");
    $stmt->bind_param("si", $status, $requestId);
    if ($stmt->execute()) {
        // Update the dashboard status
        $studentId = (int)$conn->query("SELECT student_id FROM clearance_requests WHERE clear_id = $requestId")->fetch_assoc()['student_id'];
        $dashboardStatus = 'Coordinator Rejected';
        $stmt = $conn->prepare("UPDATE students SET coordinator_dashboard_status = ? WHERE student_id = ?");
        $stmt->bind_param("si", $dashboardStatus, $studentId);
        $stmt->execute();
        
        echo "Request rejected by Coordinator and student dashboard status updated.";
    } else {
        echo "Error: " . $stmt->error;
    }
} else {
    die("Invalid action.");
}

$stmt->close();
$conn->close();
?>
