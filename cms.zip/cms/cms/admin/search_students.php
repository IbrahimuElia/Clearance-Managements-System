<?php
require_once '../config/conn.php';

$search = isset($_POST['search']) ? $_POST['search'] : '';

// Prepare SQL query
$sql = "SELECT * FROM students";
if ($search) {
    $search = $conn->real_escape_string($search);
    $sql .= " WHERE fullname LIKE '%$search%' OR regno LIKE '%$search%' OR branch LIKE '%$search%' OR course LIKE '%$search%' OR session_type LIKE '%$search%' OR email LIKE '%$search%'";
}

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table style='width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8f9fa; color: #343a40;'>
            <thead style='background-color: #007bff; color: #ffffff;'>
                <tr>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Full Name</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Registration No</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Branch</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Course</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Session</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Email</th>
                </tr>
            </thead>
            <tbody>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr style='background-color: #ffffff;'>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['fullname']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['regno']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['branch']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['course']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['session_type']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['email']}</td>
              </tr>";
    }
    echo "</tbody></table>";
} else {
    echo "<p>No user found in System.</p>";
}
?>
