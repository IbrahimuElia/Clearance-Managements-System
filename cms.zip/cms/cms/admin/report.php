<?php
require_once '../config/conn.php'; // Include your database connection
require('fpdf/fpdf.php'); // Adjust the path to FPDF as needed

// Initialize an array to hold students
$students = [];
$startDate = '';
$endDate = '';
$statusFilter = 'All';
$showDateFields = false;

// Function to fetch students based on filters
function fetchStudents($conn, $statusFilter, $startDate, $endDate) {
    $sql = "SELECT 
                `clear_id`, 
                `student_id`, 
                `full_name`, 
                `regno`, 
                `phone`, 
                `branch`, 
                `course`, 
                `session_type`, 
                `request_date`, 
                `status` 
            FROM 
                `clearance_requests` 
            WHERE 1=1";

    if ($statusFilter !== 'All') {
        $sql .= " AND `status` = ?";
    }

    if (!empty($startDate) && !empty($endDate)) {
        $sql .= " AND `request_date` BETWEEN ? AND ?";
    }

    $stmt = $conn->prepare($sql);

    // Bind parameters
    if ($statusFilter !== 'All' && !empty($startDate) && !empty($endDate)) {
        $stmt->bind_param("sss", $statusFilter, $startDate, $endDate);
    } elseif ($statusFilter !== 'All') {
        $stmt->bind_param("s", $statusFilter);
    } elseif (!empty($startDate) && !empty($endDate)) {
        $stmt->bind_param("ss", $startDate, $endDate);
    }

    $stmt->execute();
    $result = $stmt->get_result();
    $students = [];
    
    while ($row = $result->fetch_assoc()) {
        $students[] = $row; // Store results in an array
    }

    $stmt->close();
    return $students;
}

// Handle filtering and PDF generation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['generate_pdf'])) {
        // Get filter values
        $startDate = $_POST['start_date'] ?? '';
        $endDate = $_POST['end_date'] ?? '';
        $statusFilter = $_POST['status'] ?? 'All';

        // Fetch students based on the selected filters
        $students = fetchStudents($conn, $statusFilter, $startDate, $endDate);

        // Create PDF
        $pdf = new FPDF();
        $pdf->AddPage();
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(0, 10, 'List of Students', 0, 1, 'C');
        $pdf->Ln(10); // Add a line break

        // Set table headers
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(40, 10, 'Full Name', 1);
        $pdf->Cell(40, 10, 'Reg No', 1);
        $pdf->Cell(40, 10, 'Phone', 1);
        $pdf->Cell(40, 10, 'Branch', 1);
        $pdf->Cell(40, 10, 'Course', 1);
        $pdf->Cell(40, 10, 'Request Date', 1);
        $pdf->Ln();

        // Populate table with results for PDF
        $pdf->SetFont('Arial', '', 12);
        foreach ($students as $row) {
            $pdf->Cell(40, 10, htmlspecialchars($row['full_name']), 1);
            $pdf->Cell(40, 10, htmlspecialchars($row['regno']), 1);
            $pdf->Cell(40, 10, htmlspecialchars($row['phone']), 1);
            $pdf->Cell(40, 10, htmlspecialchars($row['branch']), 1);
            $pdf->Cell(40, 10, htmlspecialchars($row['course']), 1);
            $pdf->Cell(40, 10, htmlspecialchars($row['request_date']), 1);
            $pdf->Ln();
        }

        // Output the PDF
        $pdf->Output('D', 'students_list_' . date('Y-m-d') . '.pdf'); // Download the PDF
        exit; // Stop further execution
    } elseif (isset($_POST['filter'])) {
        $startDate = $_POST['start_date'] ?? '';
        $endDate = $_POST['end_date'] ?? '';
        $statusFilter = $_POST['status'] ?? 'All';

        // Fetch students based on the selected filters
        $students = fetchStudents($conn, $statusFilter, $startDate, $endDate);
    } elseif (isset($_POST['toggle_dates'])) {
        $showDateFields = true;
    }
}

// Default fetch for all students if no filter applied
if (empty($students)) {
    $students = fetchStudents($conn, 'All', '', '');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List of Students</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        h1 {
            color: #0E4BF1;
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            text-align: center;
            margin-bottom: 20px;
        }

        button {
            padding: 10px 20px;
            border: none;
            background-color: #0E4BF1;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0b3cc1; /* Darker shade for hover effect */
        }

        select, input[type="date"] {
            padding: 10px;
            margin: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .date-fields {
            display: none;
        }

        .show {
            display: block;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 0 auto;
            background-color: white;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #0E4BF1;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h1>List of Students</h1>

    <form method="POST" action="">
        <label for="status">Status:</label>
        <select id="status" name="status">
            <option value="All" <?php echo $statusFilter === 'All' ? 'selected' : ''; ?>>All</option>
            <option value="Approved" <?php echo $statusFilter === 'Approved' ? 'selected' : ''; ?>>Approved</option>
            <option value="Rejected" <?php echo $statusFilter === 'Rejected' ? 'selected' : ''; ?>>Rejected</option>
            <option value="Completed" <?php echo $statusFilter === 'Completed' ? 'selected' : ''; ?>>Completed</option>
        </select>

        <button type="button" onclick="document.getElementById('date-fields').classList.toggle('show')">Toggle Date Filter</button>
        
        <div id="date-fields" class="date-fields <?php echo $showDateFields ? 'show' : ''; ?>">
            <label for="start_date">Start Date:</label>
            <input type="date" name="start_date" value="<?php echo htmlspecialchars($startDate); ?>">
            <label for="end_date">End Date:</label>
            <input type="date" name="end_date" value="<?php echo htmlspecialchars($endDate); ?>">
        </div>

        <button type="submit" name="filter">Filter</button>
        <button type="submit" name="generate_pdf">Generate PDF</button>

        <a href="/cms/admin" style="text-decoration: none;">
        <button type="button" style="margin-left: 10px;">Back to Home</button>
    </a>    </form>

    <?php if (!empty($students)): ?>
        <table>
            <tr>
                <th>Full Name</th>
                <th>Registration No</th>
                <th>Phone</th>
                <th>Branch</th>
                <th>Course</th>
                <th>Request Date</th>
                <th>Status</th>
            </tr>
            <?php foreach ($students as $row): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($row['regno']); ?></td>
                    <td><?php echo htmlspecialchars($row['phone']); ?></td>
                    <td><?php echo htmlspecialchars($row['branch']); ?></td>
                    <td><?php echo htmlspecialchars($row['course']); ?></td>
                    <td><?php echo htmlspecialchars($row['request_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p>No records found.</p>
    <?php endif; ?>
</body>
</html>
