<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /cms"); // Redirect to login if not logged in
    exit();
}

require_once '../config/conn.php'; // Ensure this path is correct

$sql = "SELECT * FROM clearance_requests WHERE status = 'Pending Coordinator' ORDER BY request_date DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coordinator - CMS</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>/* Custom CSS for forms */
.dash-content form {
    display: flex;
    flex-direction: column;
    max-width: 800px; /* Increased max-width for a wider form */
    margin: 20px auto;
    padding: 30px;
    background-color: var(--panel-color);
    border-radius: 10px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
    border: 1px solid var(--border-color);
}

/* Grid container for form inputs */
.form-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr); /* Three columns layout */
    gap: 20px; /* Space between grid items */
    margin-bottom: 20px; /* Space below the grid */
}


/* Style for grid items */
.grid-item {
    display: flex;
    flex-direction: column;
}

/* Style for input fields */
.dash-content form input[type="text"],
.dash-content form select {
    width: 100%;
    padding: 12px;
    margin-bottom: 10px; /* Reduced margin-bottom to fit better within grid */
    border: 1px solid var(--border-color);
    border-radius: 8px;
    background-color: var(--panel-color);
    color: var(--text-color);
    font-size: 16px;
    font-weight: 400;
    outline: none;
    transition: border-color 0.3s ease, background-color 0.3s ease;
}

.dash-content form input[type="text"]:focus,
.dash-content form select:focus {
    border-color: var(--primary-color);
    background-color: var(--box3-color);
}

/* Style for submit button */
.dash-content form button {
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    background-color: var(--primary-color);
    color: var(--panel-color);
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.dash-content form button:hover {
    background-color: #0b3cc1;
    transform: translateY(-2px);
}

.dash-content form button:active {
    transform: translateY(1px);
}

/* Style for labels */
.dash-content form label {
    font-size: 16px;
    font-weight: 500;
    color: var(--text-color);
    margin-bottom: 5px;
    display: block;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    margin: 0;
    padding: 0;
}

* {
    box-sizing: border-box;
}

.open-button {
    background-color: #555;
    color: white;
    padding: 16px 20px;
    border: none;
    cursor: pointer;
    opacity: 0.8;
    position: fixed;
    bottom: 23px;
    right: 28px;
    width: 280px;
    font-size: 16px;
    font-weight: 500;
    transition: background-color 0.3s;
}

.open-button:hover {
    background-color: #0b3cc1;
    opacity: 1;
}

.form-popup {
    display: none;
    position: fixed;
    left: 28%;
    top: 50%;
    transform: translate(-50%, -50%);
    border: 0px solid #f1f1f1;
    /* background-color: white; */
    z-index: 9;
    border-radius: 8px;
    /* box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); */
    max-width: 400px;
    width: 100%;
    padding: 500px;
}

.form-container {
    display: flex;
    flex-direction: column;
}

.form-container .section {
    display: none;
}

.form-container .active {
    display: block;
}

.form-container input[type=text], 
.form-container input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    border: 1px solid #ddd;
    border-radius: 5px;
    background: #f1f1f1;
}

.form-container input[type=text]:focus, 
.form-container input[type=password]:focus {
    background-color: #ddd;
    outline: none;
}

.section-buttons {
    display: flex;
    justify-content: space-between; /* Space out the buttons */
    gap: 10px; /* Space between buttons */
    margin-top: 10px; /* Space above buttons */
}

.btn, .approve-btn {
    padding: 12px 20px;
    border: none;
    cursor: pointer;
    font-size: 14px; /* Smaller font size for better fit */
    font-weight: 500;
    border-radius: 5px;
    transition: background-color 0.3s, transform 0.3s;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 1; /* Allow buttons to grow and fit the container */
}

.btn {
    background-color: #04AA6D;
    color: white;
}

.btn:hover {
    background-color: #0b3cc1;
}

.btn.cancel {
    background-color: red;
}

.btn.cancel:hover {
    background-color: darkred;
}

.approve-btn {
    background-color: #0056b3; /* Dark blue background */
    color: white;
}

.approve-btn:hover {
    background-color: #004494; /* Darker blue on hover */
    transform: scale(1.05); /* Slightly enlarge the button */
}

.approve-btn:active {
    background-color: #003366; /* Even darker blue on click */
    transform: scale(0.98); /* Slightly shrink the button on click */
}

#checkboxContainer {
    display: grid; /* Use grid layout */
    grid-template-columns: repeat(4, 1fr); /* Three columns layout */
    gap: 20px; /* Space between grid items */
}


.subject-group {
    background-color: #f9f9f9; /* Light background for each group */
    border: 1px solid #ddd; /* Subtle border */
    border-radius: 8px; /* Rounded corners */
    padding: 15px; /* Space inside each group */
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* Subtle shadow for depth */
    flex: 1 1 calc(50% - 15px); /* Allow two items per row with some margin */
    box-sizing: border-box; /* Ensure padding and border are included in the total width */
}

#checkboxContainer label {
    margin: 5px 0;
    display: flex;
    align-items: center;
    font-size: 16px;
    color: #333; /* Dark text color for contrast */
}

#checkboxContainer input[type=checkbox] {
    margin-right: 10px;
    transform: scale(1.2); /* Larger checkbox */
    cursor: pointer; /* Change cursor to pointer */
}

/* Style for the "Other" subject input */
#checkboxContainer input[type=text] {
    margin-left: 10px; /* Space between checkbox and text input */
    padding: 5px; /* Padding for text input */
    border: 1px solid #ccc; /* Subtle border */
    border-radius: 4px; /* Rounded corners */
    width: auto; /* Auto width */
    max-width: 200px; /* Limit the width */
}


/* Overlay Styles */
#overlay {
    display: none; /* Hidden by default */
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.7); /* Semi-transparent background */
    z-index: 999; /* Above all other content */
}

/* Popup Styles */
.form-popup {
    display: none; /* Hidden by default */
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    /* background-color: white; Popup background */
    border-radius: 8px; /* Rounded corners */
    /* box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); Shadow for depth */
    z-index: 1000; /* Above the overlay */
    padding: 500px; /* Inner padding */
    width: 400px; /* Set a width for the popup */
}

/* Button Styles */
.approve-btn, .btn {
    padding: 10px 15px; /* Padding for buttons */
    border: none; /* No border */
    border-radius: 5px; /* Rounded corners */
    cursor: pointer; /* Pointer on hover */
    transition: background-color 0.3s; /* Smooth transition */
}

.approve-btn {
    background-color: #007bff; /* Primary color for approve */
    color: white; /* Text color */
}

.approve-btn:hover {
    background-color: #0056b3; /* Darker shade on hover */
}

.btn.cancel {
    background-color: #6c757d; /* Secondary color for cancel */
    color: white; /* Text color */
}

.btn.cancel:hover {
    background-color: #5a6268; /* Darker shade on hover */
}

/* Section Styles */
.section {
    margin: 10px 0; /* Spacing between sections */
}
.form-popup {
            display: none;
            position: fixed;
            left: 25%;
            top: 50%;
            transform: translate(-50%, -50%);
            border: 0px solid #ccc;
            /* background-color: white; */
            z-index: 1000;
            padding: 500px;
            /* box-shadow: 0 4px 8px rgba(0,0,0,0.2); */
        }
        #overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 500;
        }

        #overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.5);
    z-index: 1000;
}

#responseModal {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    background: white;
    padding: 20px;
    z-index: 1001;
    display: none; /* Hidden by default */
}

.close {
    cursor: pointer;
}
.scrollable-container {
    max-height: 300px; /* Set your desired height */
    overflow-y: auto;  /* Enable vertical scrolling */
    border: 1px solid #ccc; /* Optional: Add a border for better visibility */
    padding: 10px; /* Optional: Add some padding */
}



.form-container {
    display: grid; /* Use grid layout */
    grid-template-columns: 1fr; /* Single column */
    grid-gap: 15px; /* Space between grid items */
    background-color: #fff; /* White background */
    margin: 15% auto; /* Center the popup horizontally and add vertical space */
    padding: 40px; /* Adjust padding as needed */
    border: 1px solid #ccc; /* Border */
    width: 663px; /* Initial width */
    max-width: 90%; /* Ensure it doesn’t exceed 90% of viewport width */
    transition: width 0.3s ease; /* Smooth transition for width changes */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Optional: add shadow for better visibility */
    box-sizing: border-box; /* Include padding and border in element's total width and height */
}




</style>
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <img src="images/logo.png" alt="Logo">
            </div>
            <span class="logo_name">CMS</span>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="#dashboard">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dashboard</span>
                </a></li>
                <li class="dropdown">
                    <a href="#">
                        <i class="uil uil-user form-icon"></i>
                        <span class="link-name">Register User</span>
                        <i class="uil uil-angle-down dropdown-icon"></i>
                    </a>
                    <ul class="dropdown-menu nav-links">
                        <li><a href="#register-staff">Staff</a></li>
                        <li><a href="#register-student">Student</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#user">
                        <i class="uil uil-user"></i>
                        <span class="link-name">View Users</span>
                    </a>
                </li>
                <li>
    <a href="#report">
        <i class="uil uil-file-alt"></i> <!-- Change the icon to a report icon -->
        <span class="link-name">Generate Report</span>
    </a>
</li>
                <li><a href="#profile">
                    <i class="uil uil-edit"></i>
                    <span class="link-name">Edit Profile</span>
                </a></li> 
            </ul>
        </div>
    </nav>

    <div class="dashboard">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>
            <div class="search-box">
                <i"></i>
                <input type="hidden" placeholder="Search here...">
            </div>
            <?php echo "Welcome, " . htmlspecialchars($_SESSION['username']) . "!"; ?>
            <div class="profile-menu">
                <img src="images/profile.jpg" alt="Profile Image" id="profile-img">
                <div class="dropdown-content" id="dropdown-content">
                    <a href="edit-profile.php">Edit Profile</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
        </div>

        <section id="dashboard" class="section show">
            <div class="dash-content">
                <div class="activity">
                    <div class="title">
                        <i class="uil uil-tachometer-fast-alt"></i>
                        <span class="text">New Clearance Request</span>
                    </div>
                    <?php
                    // Output data in a table
                    if ($result->num_rows > 0) {
                        echo "<table style='width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8f9fa; color: #343a40;'>
                                <thead style='background-color: #007bff; color: #ffffff;'>
                                    <tr>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Full Name</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Registration No</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Branch</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Course</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Session</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Clearance Date</th>
                                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Action</th>
                                    </tr>
                                </thead>
                                <tbody>";

                        while ($row = $result->fetch_assoc()) {
                            echo "<tr style='background-color: #ffffff;'>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['full_name']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['regno']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['branch']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['course']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['session_type']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['request_date']}</td>
                                    <td style='padding: 12px; border: 1px solid #dee2e6;'><a href='#'class='view-details' data-id='{$row['clear_id']}' style='display: inline-block; padding: 8px 16px; font-size: 14px; font-weight: bold; color: #ffffff; background-color: #007bff; border: none; border-radius: 5px; text-decoration: none; text-align: center; cursor: pointer; transition: background-color 0.3s ease;'>View</a></td>
                                  </tr>";
                        }
                        echo "</tbody>
                            </table>";
                    } else {
                        echo "<p>No requests pending approval.</p>";
                    }
                    ?>
<div class="form-popup" id="myForm">
    <form class="form-container">
        <div class="section" id="noDebtSection">
            <h1>Regarding of Status</h1>
            <p>If Student Cleared all subject, Click Approve.</p>
            <div class="section-buttons">
                <button type="button" class="approve-btn" id="approveBtn">Approve</button>
                <button type="button" class="btn" onclick="showCheckDebt()">Reject</button>
                <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
            </div>
        </div>
        

        <div class="section" id="checkDebtSection">
    <div id="checkboxContainer">
        <div class="subject-group">
            <label>
                <input type="checkbox" name="subjects[]" value="Systems Analysis and Design"> Systems Analysis and Design
                <div class="options">
                    <label><input type="checkbox" name="Systems Analysis and Design_options[]" value="Sup"> Sup</label>
                    <label><input type="checkbox" name="Systems Analysis and Design_options[]" value="Inco"> Inco</label>
                    <label><input type="checkbox" name="Systems Analysis and Design_options[]" value="CRY"> CRY</label>
                </div>
            </label>
        </div>

        <div class="subject-group">
            <label>
                <input type="checkbox" name="subjects[]" value="Enterprise Networking and Security"> Enterprise Networking and Security
                <div class="options">
                    <label><input type="checkbox" name="Enterprise Networking and Security_options[]" value="Sup"> Sup</label>
                    <label><input type="checkbox" name="Enterprise Networking and Security_options[]" value="Inco"> Inco</label>
                    <label><input type="checkbox" name="Enterprise Networking and Security_options[]" value="CRY"> CRY</label>
                </div>
            </label>
        </div>

        <div class="subject-group">
            <label>
                <input type="checkbox" name="subjects[]" value="Web Application Development"> Web Application Development
                <div class="options">
                    <label><input type="checkbox" name="Web Application Development_options[]" value="Sup"> Sup</label>
                    <label><input type="checkbox" name="Web Application Development_options[]" value="Inco"> Inco</label>
                    <label><input type="checkbox" name="Web Application Development_options[]" value="CRY"> CRY</label>
                </div>
            </label>
        </div>

        <div class="subject-group">
            <label>
                <input type="checkbox" name="subjects[]" value="Object Oriented Techniques in Software Development"> Object Oriented Techniques in Software Development
                <div class="options">
                    <label><input type="checkbox" name="Object Oriented Techniques in Software Development_options[]" value="Sup"> Sup</label>
                    <label><input type="checkbox" name="Object Oriented Techniques in Software Development_options[]" value="Inco"> Inco</label>
                    <label><input type="checkbox" name="Object Oriented Techniques in Software Development_options[]" value="CRY"> CRY</label>
                </div>
            </label>
        </div>

        <div class="subject-group">
            <label>
                <input type="checkbox" name="subjects[]" value="Essentials of Project Management"> Essentials of Project Management
                <div class="options">
                    <label><input type="checkbox" name="Essentials of Project Management_options[]" value="Sup"> Sup</label>
                    <label><input type="checkbox" name="Essentials of Project Management_options[]" value="Inco"> Inco</label>
                    <label><input type="checkbox" name="Essentials of Project Management_options[]" value="CRY"> CRY</label>
                </div>
            </label>
        </div>

        <div class="subject-group">
            <label>
                <input type="checkbox" name="subjects[]" value="Fundamentals of Accounting"> Fundamentals of Accounting
                <div class="options">
                    <label><input type="checkbox" name="Fundamentals of Accounting_options[]" value="Sup"> Sup</label>
                    <label><input type="checkbox" name="Fundamentals of Accounting_options[]" value="Inco"> Inco</label>
                    <label><input type="checkbox" name="Fundamentals of Accounting_options[]" value="CRY"> CRY</label>
                </div>
            </label>
        </div>

        <div class="subject-group">
            <label>
                <input type="checkbox" name="subjects[]" value="Server Administration"> Server Administration
                <div class="options">
                    <label><input type="checkbox" name="Server Administration_options[]" value="Sup"> Sup</label>
                    <label><input type="checkbox" name="Server Administration_options[]" value="Inco"> Inco</label>
                    <label><input type="checkbox" name="Server Administration_options[]" value="CRY"> CRY</label>
                </div>
            </label>
        </div>

        <div class="subject-group">
            <label>
                <input type="checkbox" name="subjects[]" value="Database Administration"> Database Administration
                <div class="options">
                    <label><input type="checkbox" name="Database Administration_options[]" value="Sup"> Sup</label>
                    <label><input type="checkbox" name="Database Administration_options[]" value="Inco"> Inco</label>
                    <label><input type="checkbox" name="Database Administration_options[]" value="CRY"> CRY</label>
                </div>
            </label>
        </div>

        <div class="subject-group">
            <label>
                <input type="checkbox" name="subjects[]" value="Mobile Applications Development"> Mobile Applications Development
                <div class="options">
                    <label><input type="checkbox" name="Mobile Applications Development_options[]" value="Sup"> Sup</label>
                    <label><input type="checkbox" name="Mobile Applications Development_options[]" value="Inco"> Inco</label>
                    <label><input type="checkbox" name="Mobile Applications Development_options[]" value="CRY"> CRY</label>
                </div>
            </label>
        </div>

        <div class="subject-group">
            <label>
                <input type="checkbox" name="subjects[]" value="Final Year Project"> Final Year Project
                <div class="options">
                    <label><input type="checkbox" name="Final Year Project_options[]" value="Sup"> Sup</label>
                    <label><input type="checkbox" name="Final Year Project_options[]" value="Inco"> Inco</label>
                    <label><input type="checkbox" name="Final Year Project_options[]" value="CRY"> CRY</label>
                </div>
            </label>
        </div>
        <div>
    <label for="otherReason">Other Reason:</label>
    <input type="hidden" name="otherReason" id="otherReason">
</div>
<div>
    <label for="coordinator_comments">Comments:</label>
    <textarea id="coordinator_comments"></textarea>
</div>

    </div>



            <div class="section-buttons">
                <button type="button" class="btn" onclick="sendReject()">Submit Rejection</button>
                <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
            </div>
        </div>
    </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const viewButtons = document.querySelectorAll('.view-details');

    viewButtons.forEach(button => {
        button.addEventListener('click', function () {
            currentClearId = this.getAttribute('data-id');
            openForm();
        });
    });

    // Add the reject button listener
    document.getElementById('rejectBtn').addEventListener('click', function() {
        // Change the width of the form container
        document.getElementById("formContainer").style.width = "600px"; // Change this width as needed
        showCheckDebt(); // Show the check debt section if needed
    });
});

function openForm() {
    document.getElementById("myForm").style.display = "block";
    showNoDebt();
}

function closeForm() {
    document.getElementById("myForm").style.display = "none";
}

function showNoDebt() {
    document.getElementById("noDebtSection").classList.add("active");
    document.getElementById("checkDebtSection").classList.remove("active");
}

function showCheckDebt() {
    document.getElementById("noDebtSection").classList.remove("active");
    document.getElementById("checkDebtSection").classList.add("active");
}

function sendReject() {
    const checkedItems = Array.from(document.querySelectorAll('#checkboxContainer input[type=checkbox]:checked'))
                              .map(checkbox => checkbox.value);
    const otherReason = document.querySelector('input[name="otherReason"]').value;
    const comment = document.getElementById('coordinator_comments').value;

    if (checkedItems.length > 0 || otherReason.trim() !== '' || comment.trim() !== '') {
        const data = new URLSearchParams({
            clear_id: currentClearId,
            reasons: JSON.stringify(checkedItems),
            otherReason: otherReason,
            comment: comment,
            reject: true
        });

        const xhr = new XMLHttpRequest();
        xhr.open("POST", "handle_rejection.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.send(data.toString());

        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                showModal(xhr.responseText);
            } else {
                showModal("Failed to process rejection.");
            }
        };

        xhr.onerror = function() {
            showModal("An error occurred while processing your request.");
        };

        closeForm(); // Close form after submission
    } else {
        alert('Please select at least one reason or provide comments.');
    }
}

document.getElementById('approveBtn').addEventListener('click', function() {
    if (currentClearId) {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "handle_approval.php", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

        const data = `clear_id=${encodeURIComponent(currentClearId)}&approve=true`;
        xhr.send(data);

        xhr.onload = function () {
            if (xhr.status >= 200 && xhr.status < 300) {
                showModal(xhr.responseText);
            } else {
                showModal("Failed to process approval.");
            }
        };

        xhr.onerror = function() {
            showModal("An error occurred while processing your request.");
        };
    } else {
        showModal("No request ID found.");
    }
});

function showModal(message) {
    document.getElementById('modalMessage').textContent = message;
    document.getElementById('responseModal').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

function closeModal() {
    document.getElementById('responseModal').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}
</script>

<!-- Modal HTML -->
<div id="responseModal" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); width:300px; background-color:white; border:1px solid #ddd; border-radius:5px; box-shadow:0px 0px 10px rgba(0,0,0,0.2); z-index:1000;">
    <div style="padding:20px;">
        <span id="modalMessage"></span>
        <button onclick="closeModal()" style="display:block; margin-top:10px; padding:10px; background-color:#007bff; color:white; border:none; border-radius:5px; cursor:pointer;">Close</button>
    </div>
</div>

<!-- Overlay for Modal -->
<div id="overlay" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:999;"></div>


<div class="dash-content">
            <div class="activity">
                <div class="title">
                    <i class="uil uil-clock-three"></i>
                    <span class="text">Rejected Clearance</span>
                </div>
                <?php
                require_once '../config/conn.php';
                $sql = "SELECT * FROM clearance_requests WHERE coordinater_view_reject = 'yes' ORDER BY request_date DESC";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    echo "<table style='width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8f9fa; color: #343a40;'>
                            <thead style='background-color: #007bff; color: #ffffff;'>
                                <tr>
                                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Full Name</th>
                                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Registration No</th>
                                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Branch</th>
                                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Course</th>
                                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Reason Reapply</th>
                                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Attached Document</th>
                                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Action</th>
                                </tr>
                            </thead>
                            <tbody>";

                    while ($row = $result->fetch_assoc()) {
                        echo "<tr style='background-color: #ffffff;'>
                                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['full_name']}</td>
                                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['regno']}</td>
                                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['branch']}</td>
                                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['course']}</td>
                                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['reapplyReason']}</td>
                                <td style='padding: 12px; border: 1px solid #dee2e6;'>";
                        
                        if (!empty($row['coordinator_document_path'])) {
                            echo "<a href='" . htmlspecialchars($row['coordinator_document_path']) . "' target='_blank' style='color: #007bff; text-decoration: underline;'>View Document</a>";
                        } else {
                            echo "No document available";
                        }
                        
                        echo "</td>
                                                            <td style='padding: 12px; border: 1px solid #dee2e6;'><a href='#'class='view-details' data-id='{$row['clear_id']}' style='display: inline-block; padding: 8px 16px; font-size: 14px; font-weight: bold; color: #ffffff; background-color: #007bff; border: none; border-radius: 5px; text-decoration: none; text-align: center; cursor: pointer; transition: background-color 0.3s ease;'>View</a></td>

                      </tr>";
                    }
                    echo "</tbody>
                        </table>";
                } else {
                    echo "<p>No requests pending approval.</p>";
                }
                ?>
            </div>
        </div>

        <div id="overlay" onclick="closeForm()"></div>

        <!-- Form Popup -->
        <div class="form-popup" id="approveReapply">
            <form class="form-container" onsubmit="return false;">
                <h1>Approve Request</h1>
                <p>Do you want to approve this request?</p>
                <div class="section-buttons">
                    <button type="button" id="approveBtn" onclick="approveRequest()">Approve</button>
                    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
                </div>
            </form>
        </div>

        </section>
        
        <section id="register-staff" class="section">
            <div class="dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="uil uil-tachometer-fast-alt"></i>
                        <span class="text">Register Staff</span>
                    </div>
                    <div class="boxes">
                        <div class="form-container">
                            <form method="POST" action="register_staff.php">
                                <div class="form-grid">
                                    <div class="grid-item">
                                        <label for="firstname">First Name:</label>
                                        <input type="text" name="firstname" id="firstname" placeholder="First Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="lastname">Last Name:</label>
                                        <input type="text" name="lastname" id="lastname" placeholder="Last Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="email">Email:</label>
                                        <input type="email" name="email" id="email" placeholder="Email" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="password">Password:</label>
                                        <input type="password" name="password" id="password" placeholder="Password" required>
                                    </div>
                                </div>
                                <button type="submit">Register</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section><section id="register-student" class="section">
            <div class="dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="uil uil-tachometer-fast-alt"></i>
                        <span class="text">Register Student</span>
                    </div>
                    <div class="boxes">
                        <div class="form-container">
                            <form method="POST" action="register_student.php">
                                <div class="form-grid">
                                    <div class="grid-item">
                                        <label for="firstname">First Name:</label>
                                        <input type="text" name="firstname" id="firstname" placeholder="First Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="lastname">Last Name:</label>
                                        <input type="text" name="lastname" id="lastname" placeholder="Last Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="regno">Reg No:</label>
                                        <input type="text" name="regno" id="regno" placeholder="Reg No" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="email">Email:</label>
                                        <input type="email" name="email" id="email" placeholder="Email" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="password">Password:</label>
                                        <input type="password" name="password" id="password" placeholder="Password" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="branch">Branch:</label>
                                        <select name="branch" id="branch" required>
                                            <option value="" disabled selected>Select Branch</option>
                                            <option value="Dodoma">Dodoma Branch</option>
                                            <option value="Dar es Salaam">Dar es Salaam (Main)</option>
                                        </select>
                                    </div>
                                    <div class="grid-item">
                                        <label for="course">Course:</label>
                                        <select name="course" id="course" required>
                                            <option value="" disabled selected>Select Course</option>
                                            <option value="DCIT">Diploma in Information Communication Technology</option>
                                            <option value="DBIT">Diploma in Business Information Technology</option>
                                        </select>
                                    </div>
                                    <div class="grid-item">
                                        <label for="session_type">Session:</label>
                                        <select name="session_type" id="session_type" required>
                                            <option value="" disabled selected>Select Session</option>
                                            <option value="Morning">Morning</option>
                                            <option value="Evening">Evening</option>
                                        </select>
                                    </div>
                                </div>
                                <button type="submit">Register Student</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="user" class="section">
        <div class="dash-content">
            <div class="activity" onload="searchStudents()">
                <div class="title">
                    <i class="uil uil-clock-three"></i>
                    <span class="text">List of all Student</span>
                </div>
                <?php
require_once '../config/conn.php';

// Initialize search variable
$search = isset($_POST['search']) ? $_POST['search'] : '';

// Prepare SQL query
$sql = "SELECT * FROM students";
if ($search) {
    $search = $conn->real_escape_string($search);
    $sql .= " WHERE fullname LIKE '%$search%' OR regno LIKE '%$search%' OR branch LIKE '%$search%' OR course LIKE '%$search%' OR session_type LIKE '%$search%' OR email LIKE '%$search%'";
}

$result = $conn->query($sql);
?>


  
    <script>
        function searchStudents() {
            const query = document.getElementById('search').value;
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'search_students.php', true);
            xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                document.getElementById('studentTable').innerHTML = this.responseText;
            };
            xhr.send('search=' + encodeURIComponent(query));
        }
    </script>


<input type="text" id="search" placeholder="Search..." onkeyup="searchStudents()" style="padding: 10px; width: 300px; border: 1px solid #dee2e6; border-radius: 4px; margin: 20px;">

<div id="studentTable">
    <?php
    if ($result->num_rows > 0) {
        echo "<table style='width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8f9fa; color: #343a40;'>
                <thead style='background-color: #007bff; color: #ffffff;'>
                    <tr>
                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Full Name</th>
                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Registration No</th>
                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Branch</th>
                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Course</th>
                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Session</th>
                        <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Email</th>
                    </tr>
                </thead>
                <tbody>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr style='background-color: #ffffff;'>
                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['fullname']}</td>
                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['regno']}</td>
                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['branch']}</td>
                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['course']}</td>
                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['session_type']}</td>
                    <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['email']}</td>
                  </tr>";
        }
        echo "</tbody></table>";
    } else {
        echo "<p>No user found in System.</p>";
    }
    ?>
</div>



            </div>
        </div>
    </section>
    <section id='report' class="section">
    <div class="dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="uil uil-tachometer-fast-alt"></i>
                        <span class="text">Register Student</span>
                    </div>
                    <div>       <a href="report.php" class="btn">Generate Full Report</a></div>

                </div>
                </div>
            </section>

            <section id='profile' class="section">
            <div class="overview">
                    <div class="title">
                        <i class="uil uil-tachometer-fast-alt"></i>
                        <span class="text">Register Student</span>
                    </div>
                    
                <div>

                </div>
                <h1>Update Staff Details</h1>
                <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }

        h1 {
            color: #0E4BF1;
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            display: grid;
            grid-template-columns: 1fr 1fr; /* Two equal columns */
            gap: 15px; /* Space between grid items */
        }

        label {
            grid-column: span 2; /* Labels span across both columns */
            margin-top: 10px;
        }

        input[type="text"], input[type="email"], input[type="password"], select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        button {
            grid-column: span 2; /* Button spans across both columns */
            padding: 10px 20px;
            border: none;
            background-color: #0E4BF1;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #0b3cc1;
        }
    </style>
    <?php
if (isset($_GET['user_id'])) {
    $id = $_GET['user_id'];
    $sql = "SELECT `role`, `firstname`, `lastname`, `username`, `email` FROM `staff` WHERE `id` = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $staff = $result->fetch_assoc();
        $role = $staff['role'];
        $firstname = $staff['firstname'];
        $lastname = $staff['lastname'];
        $username = $staff['username'];
        $email = $staff['email'];
    } else {
        echo "<p>No staff found with that ID.</p>";
    }

    $stmt->close();
}
    ?>

    <h1>Update Staff Details</h1>
    <form method="POST" action="">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($id); ?>" required>
        
        <label for="role">Role:</label>
        <input type="text" name="role" value="<?php echo htmlspecialchars($role); ?>" required>
        
        <label for="firstname">First Name:</label>
        <input type="text" name="firstname" value="<?php echo htmlspecialchars($firstname); ?>" required>

        <label for="lastname">Last Name:</label>
        <input type="text" name="lastname" value="<?php echo htmlspecialchars($lastname); ?>" required>

        <label for="username">Username:</label>
        <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" required>

        <label for="email">Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>

        <label for="password">Password:</label>
        <input type="password" name="password" value="<?php echo htmlspecialchars($password); ?>" required>

        <button type="submit">Update Staff</button>
    </form>
                </div>
            
            </section>
<!-- Example Modal Structure -->
<div id="responseModal" style="display:none;">
    <div class="modal-content">
        <span id="closeModalButton" class="close-button">&times;</span>
        <p id="modalMessage"></p>
    </div>
</div>
<div id="overlay" style="display:none;"></div>

<script>
// JavaScript to handle navigation between sections
const sections = document.querySelectorAll('.section');
const navLinks = document.querySelectorAll('nav a');

navLinks.forEach(link => {
    link.addEventListener('click', (event) => {
        event.preventDefault();
        const targetSection = document.getElementById(link.hash.substr(1));

        sections.forEach(section => {
            section.classList.remove('show');
        });

        targetSection.classList.add('show');
    });
});

// JavaScript to fetch and display student details
document.addEventListener("DOMContentLoaded", function() {
    // Event listeners for viewing student details
    document.querySelectorAll('.view-details').forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const id = this.getAttribute('data-id');
            fetchStudentDetails(id);
        });
    });

    // Event listeners for reapply buttons
    document.querySelectorAll('.view-reapply').forEach(button => {
        button.addEventListener('click', function () {
            currentClearId = this.getAttribute('data-id');
            openForm();
        });
    });

    // Event listeners for approval buttons
    document.querySelectorAll('.approve-button').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault(); // Prevent default link behavior
            const clearId = this.getAttribute('data-id');
            approveRequest(clearId);
        });
    });
});

// Function to fetch student details
function fetchStudentDetails(id) {
    fetch(`get_student_details.php?id=${id}`)
        .then(response => response.text())
        .then(data => {
            document.getElementById('student-details').innerHTML = data;
        })
        .catch(error => console.error('Error fetching student details:', error));
}

// Open form function
function openForm() {
    document.getElementById("myForm").style.display = "block"; // Show form
    document.getElementById("overlay").style.display = "block"; // Show overlay
    showNoDebt(); // Call this if applicable
}

// Close form function
function closeForm() {
    document.getElementById("myForm").style.display = "none"; // Hide the form
    document.getElementById("overlay").style.display = "none"; // Hide overlay
}

// Show no debt section
function showNoDebt() {
    document.getElementById("noDebtSection").classList.add("active");
    document.getElementById("checkDebtSection").classList.remove("active");
}

// Approve request function
function approveRequest(clearId) {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "handle_approval.php", true); // Update the URL as needed
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");

    const data = `clear_id=${encodeURIComponent(clearId)}&approve=true`; // Send clear_id and approve flag
    xhr.send(data);

    xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
            const response = JSON.parse(xhr.responseText);
            showModal(response.success || response.error); // Show modal message
            closeForm(); // Close the form after approval
            location.reload(); // Refresh the page to show updated data
        } else {
            showModal("Failed to process approval.");
        }
    };

    xhr.onerror = function() {
        showModal("An error occurred while processing your request.");
    };
}

// Function to show the modal
function showModal(message) {
    const modalMessageElement = document.getElementById('modalMessage'); // Modal message element
    modalMessageElement.textContent = message; // Set message text
    document.getElementById('responseModal').style.display = 'block'; // Show the modal
    document.getElementById('overlay').style.display = 'block'; // Show overlay
}

// Function to close the modal
function closeModal() {
    document.getElementById('responseModal').style.display = 'none'; // Hide the modal
    document.getElementById('overlay').style.display = 'none'; // Hide overlay
}

// Event listener for modal close button
document.getElementById('closeModalButton').addEventListener('click', closeModal);
</script>


    </div>
    <div id="overlay" style="display: none;"></div>
<div id="responseModal" style="display: none;">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <p id="modalMessage"></p>
    </div>
</div>
</body>
</html>
