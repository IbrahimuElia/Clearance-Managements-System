<?php
// Database credentials
require_once '../config/conn.php';

// Sanitize and validate input
$firstname = $conn->real_escape_string($_POST['firstname']);
$lastname = $conn->real_escape_string($_POST['lastname']);
$regno = $conn->real_escape_string($_POST['regno']);
$email = $conn->real_escape_string($_POST['email']);
$password = $conn->real_escape_string($_POST['password']);
$branch = $conn->real_escape_string($_POST['branch']);
$course = $conn->real_escape_string($_POST['course']);
$session_type = $conn->real_escape_string($_POST['session_type']);

// Combine firstname and lastname into fullname
$fullname = $firstname . ' ' . $lastname;

// Hash the password using MD5
$hashed_password = md5($password);

// Check if the registration number already exists
$sql = "SELECT * FROM students WHERE regno = '$regno'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Update existing record
    $sql = "UPDATE students SET 
                fullname = '$fullname', 
                email = '$email', 
                password = '$hashed_password', 
                branch = '$branch', 
                course = '$course', 
                session_type = '$session_type' 
            WHERE regno = '$regno'";
} else {
    // Insert new record
    $sql = "INSERT INTO students (fullname, regno, email, password, branch, course, session_type) 
            VALUES ('$fullname', '$regno', '$email', '$hashed_password', '$branch', '$course', '$session_type')";
}

$response = [];

if ($conn->query($sql) === TRUE) {
    $response['success'] = "Record updated successfully";
} else {
    $response['error'] = "Error: " . $conn->error;
}

echo json_encode($response);
$conn->close();
?>

