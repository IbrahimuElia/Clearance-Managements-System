<?php

require_once '../config/conn.php';

// Check if clear_id is set and is a valid integer
if (isset($_POST['clear_id'])) {
    $requestId = intval($_POST['clear_id']);
    $approve = isset($_POST['approve']);
    $reject = isset($_POST['reject']);
    $coordinatorStatusDate = date('Y-m-d'); // Current date for status update

    // Handle approval
    if ($approve && !$reject) {
        $status = 'Pending Finance Approval';
        $stmt = $conn->prepare("UPDATE clearance_requests SET status = ? rejected_status = 'Pending Finance Approval' WHERE clear_id = ?");
        $stmt->bind_param("si", $status, $requestId);
        if ($stmt->execute()) {
            // Update the dashboard status
            $studentId = (int)$conn->query("SELECT student_id FROM clearance_requests WHERE clear_id = $requestId")->fetch_assoc()['student_id'];
            $dashboardStatus = 'Coordinator Approved';
            $stmt = $conn->prepare("UPDATE students SET coordinator_dashboard_status = ? WHERE student_id = ?");
            $stmt->bind_param("si", $dashboardStatus, $studentId);
            $stmt->execute();
            
            echo json_encode(['success' => 'Request approved by Coordinator and student dashboard status updated.']);
        } else {
            echo json_encode(['error' => 'Error: ' . $stmt->error]);
        }
    } 
    // Handle rejection
    elseif ($reject && !$approve) {
        $status = 'Rejected';
        if (isset($_POST['reasons'])) {
            $reasons = json_decode($_POST['reasons'], true); // Decode the reasons array

            // Check for "Other" reason
            if (isset($_POST['otherReason']) && !empty(trim($_POST['otherReason']))) {
                $reasons[] = trim($_POST['otherReason']);
            }

            // Convert reasons to a comma-separated string
            $reasonsString = implode(", ", $reasons);
            $coordinator_comments = isset($_POST['coordinator_comments']) ? $_POST['coordinator_comments'] : '';

            // Update the clearance request status to rejected
            $stmt = $conn->prepare("UPDATE clearance_requests SET status = 'Coordinator Rejected', rejected_status = 'Hahahah', coordinater_view_reject = 'No', rejection_reasons = ?, coordinator_comments = ?, date_conducted = ? WHERE clear_id = ?");
            $dateConducted = date('Y-m-d');

            if ($stmt === false) {
                echo json_encode(['error' => 'Prepare failed: ' . $conn->error]);
                exit();
            }

            $stmt->bind_param("sssi", $reasonsString, $coordinator_comments, $dateConducted, $requestId);

            if ($stmt->execute()) {
                // Check if the row was affected
                if ($stmt->affected_rows > 0) {
                    // Update dashboard status for the student
                    $studentId = (int)$conn->query("SELECT student_id FROM clearance_requests WHERE clear_id = $requestId")->fetch_assoc()['student_id'];
                    $dashboardStatus = 'Coordinator Rejected';
                    $stmt = $conn->prepare("UPDATE students SET coordinator_dashboard_status = ? WHERE student_id = ?");
                    $stmt->bind_param("si", $dashboardStatus, $studentId);
                    $stmt->execute();

                    echo json_encode(['success' => 'Request rejected successfully and dashboard status updated.']);
                } else {
                    echo json_encode(['error' => 'No changes made to request status.']);
                }
            } else {
                echo json_encode(['error' => 'Failed to update rejection status: ' . $stmt->error]);
            }
        } else {
            echo json_encode(['error' => 'No reasons provided for rejection.']);
        }
    } else {
        echo json_encode(['error' => 'Invalid action.']);
    }

    $stmt->close();
} else {
    echo json_encode(['error' => 'Invalid request.']);
}

$conn->close();
?>
