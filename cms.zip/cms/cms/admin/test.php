<?php
require_once '../config/conn.php';

// Fetch data from database
$sql = "SELECT * FROM clearance_requests";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table style='width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8f9fa; color: #343a40;'>
            <thead style='background-color: #007bff; color: #ffffff;'>
                <tr>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Full Name</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Registration No</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Branch</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Course</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Session</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Clearance Date</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Action</th>
                </tr>
            </thead>
            <tbody>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr style='background-color: #ffffff;'>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['full_name']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['regno']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['branch']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['course']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['session_type']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['request_date']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>
                    <button class='view-details' data-id='{$row['clear_id']}' style='display: inline-block; padding: 8px 16px; font-size: 14px; font-weight: bold; color: #ffffff; background-color: #007bff; border: none; border-radius: 5px; text-decoration: none; text-align: center; cursor: pointer; transition: background-color 0.3s ease;'>View</button>
                </td>
              </tr>";
    }
    echo "</tbody>
        </table>";
} else {
    echo "<p>No requests pending approval.</p>";
}

$conn->close();
?>

<!-- Form HTML -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Debt Management Form</title>
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
            margin: 0;
            padding: 0;
        }
        * {
            box-sizing: border-box;
        }
        .open-button {
            background-color: #555;
            color: white;
            padding: 16px 20px;
            border: none;
            cursor: pointer;
            opacity: 0.8;
            position: fixed;
            bottom: 23px;
            right: 28px;
            width: 280px;
            font-size: 16px;
            font-weight: 500;
            transition: background-color 0.3s;
        }
        .open-button:hover {
            background-color: #0b3cc1;
            opacity: 1;
        }
        .form-popup {
            display: none;
            position: fixed;
            left: 50%;
            top: 50%;
            transform: translate(-50%, -50%);
            border: 3px solid #f1f1f1;
            background-color: white;
            z-index: 9;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            max-width: 400px;
            width: 100%;
            padding: 20px;
        }
        .form-container {
            display: flex;
            flex-direction: column;
        }
        .form-container .section {
            display: none;
        }
        .form-container .active {
            display: block;
        }
        .form-container input[type=text], 
        .form-container input[type=password] {
            width: 100%;
            padding: 15px;
            margin: 5px 0 22px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            background: #f1f1f1;
        }
        .form-container input[type=text]:focus, 
        .form-container input[type=password]:focus {
            background-color: #ddd;
            outline: none;
        }
        .btn, .approve-btn {
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            font-weight: 500;
            border-radius: 5px;
            transition: background-color 0.3s, transform 0.3s;
            text-align: center;
            display: inline-block;
            margin: 10px;
        }
        .btn {
            background-color: #04AA6D;
            color: white;
        }
        .btn:hover {
            background-color: #0b3cc1;
        }
        .btn.cancel {
            background-color: red;
        }
        .btn.cancel:hover {
            background-color: darkred;
        }
        .approve-btn {
            background-color: #0056b3; /* Dark blue background */
            color: white;
        }
        .approve-btn:hover {
            background-color: #004494; /* Darker blue on hover */
            transform: scale(1.05); /* Slightly enlarge the button */
        }
        .approve-btn:active {
            background-color: #003366; /* Even darker blue on click */
            transform: scale(0.98); /* Slightly shrink the button on click */
        }
        .section-buttons {
            display: flex;
            justify-content: center;
            gap: 20px; /* Space between buttons */
        }
        #checkboxContainer {
            display: flex;
            flex-direction: column;
            margin-top: 20px;
        }
        #checkboxContainer label {
            margin: 5px 0;
            display: flex;
            align-items: center;
            font-size: 16px;
        }
        #checkboxContainer input[type=checkbox] {
            margin-right: 10px;
            transform: scale(1.2);
        }
    </style>
</head>
<body>

<!-- Form Popup -->
<div class="form-popup" id="myForm">
  <form class="form-container">
    <div class="section" id="noDebtSection">
      <h1>No Debt</h1>
      <p>You have no debts to manage at the moment.</p>
      <div class="section-buttons">
        <button type="button" class="approve-btn" onclick="showCheckDebtItems()">Approve</button>
        <button type="button" class="btn" onclick="showCheckDebt()">Check Debt</button>
      </div>
    </div>
    
    <div class="section" id="checkDebtSection">
      <h1>Check Debt</h1>
      <p>Select to add debt:</p>
      <div id="checkboxContainer">
        <!-- Add checkboxes for debt items here -->
        <label><input type="checkbox" name="debtItem" value="item1"> Item 1</label>
        <label><input type="checkbox" name="debtItem" value="item2"> Item 2</label>
        <label><input type="checkbox" name="debtItem" value="item3"> Item 3</label>
      </div>
      <div class="section-buttons">
        <button type="button" class="btn" onclick="sendDebt()">Send Debt</button>
        <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
      </div>
    </div>
  </form>
</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const viewButtons = document.querySelectorAll('.view-details');
    
    viewButtons.forEach(button => {
        button.addEventListener('click', function () {
            const clearId = this.getAttribute('data-id');
            openForm(clearId); // Pass the clearId to the function to handle form visibility and data
        });
    });
});

function openForm(clearId) {
    document.getElementById("myForm").style.display = "block";
    showNoDebt(); // Ensure "No Debt" section is visible when the form opens
    // You can use clearId to fetch and display specific data if needed
}

function closeForm() {
    document.getElementById("myForm").style.display = "none";
}

function showNoDebt() {
    document.getElementById("noDebtSection").classList.add("active");
    document.getElementById("checkDebtSection").classList.remove("active");
}

function showCheckDebt() {
    document.getElementById("noDebtSection").classList.remove("active");
    document.getElementById("checkDebtSection").classList.add("active");
}

function showCheckDebtItems() {
    document.getElementById("checkboxContainer").style.display = "block";
}

function sendDebt() {
    const checkedItems = Array.from(document.querySelectorAll('#checkboxContainer input[type=checkbox]:checked'))
                              .map(checkbox => checkbox.value);
    if (checkedItems.length > 0) {
        alert(`Debt items sent: ${checkedItems.join(', ')}`);
        // Add further processing here (e.g., send data to the server)
        closeForm();
    } else {
        alert('Please select at least one item to add debt.');
    }
}
</script>

</body>
</html>
