<?php
require_once '../config/conn.php';

// Check if the request method is POST and 'clear_id' and 'approve' fields are set
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_id']) && isset($_POST['approve'])) {
    // Get and sanitize form data
    $requestId = intval($_POST['clear_id']);
    $approve = $_POST['approve'] === 'true'; // Convert to boolean

    if ($approve) {
        // Approve the request
        $status = 'Pending Finance Approval';
        $rejected_status = 'Approved';
        
        // Update clearance_requests with the new status
        $stmt = $conn->prepare("UPDATE clearance_requests SET status = ?, rejected_status = ? WHERE clear_id = ?");
        
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("si", $status, $requestId);
        if ($stmt->execute()) {
            // Update the dashboard status
            $result = $conn->query("SELECT student_id FROM clearance_requests WHERE clear_id = $requestId");

            if (!$result) {
                die("Query failed: " . $conn->error);
            }

            $studentId = (int)$result->fetch_assoc()['student_id'];
            $dashboardStatus = 'Finance Approved';
            
            // Update the dashboard status for the student
            $stmt = $conn->prepare("UPDATE students SET finance_dashboard_status = ? WHERE student_id = ?");

            if (!$stmt) {
                die("Prepare failed: " . $conn->error);
            }

            $stmt->bind_param("si", $dashboardStatus, $studentId);
            if ($stmt->execute()) {
                echo "Request approved and student dashboard status updated.";
            } else {
                echo "Error updating dashboard status: " . $stmt->error;
            }
        } else {
            echo "Error updating request status: " . $stmt->error;
        }
    } else {
        echo "Approval not granted.";
    }

    $stmt->close();
} else {
    die("Invalid request.");
}

$conn->close();
?>
