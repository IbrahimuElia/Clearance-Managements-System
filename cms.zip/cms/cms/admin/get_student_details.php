<?php
require_once '../config/conn.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_id'])) {
    $clearId = intval($_POST['clear_id']);

    // Fetch student details based on clear_id
    $stmt = $conn->prepare("SELECT student_id, student_name, other_details FROM clearance_requests WHERE clear_id = ?");
    $stmt->bind_param("i", $clearId);
    
    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $student = $result->fetch_assoc();
            echo json_encode($student);
        } else {
            echo json_encode(['error' => 'No student found.']);
        }
    } else {
        echo json_encode(['error' => 'Query execution failed.']);
    }

    $stmt->close();
} else {
    echo json_encode(['error' => 'Invalid request.']);
}

$conn->close();
?>
