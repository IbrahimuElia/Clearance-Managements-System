<?php

session_start(); // Start session
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /cms"); // Redirect to login if not logged in
    exit();
}
require_once '../config/conn.php';
$role = $_POST['role'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];

if (empty($firstname) || empty($lastname) || empty($username) || empty($email) || empty($password)) {
    die("All fields are required.");
}


$hashed_password = password_hash($password, PASSWORD_BCRYPT);


$stmt = $conn->prepare("INSERT INTO staff (role,firstname, lastname, username, email, password) VALUES (?,?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $role, $firstname, $lastname, $username, $email, $hashed_password);


if ($stmt->execute()) {
  
    header("Location: http://localhost/cms/admin/test.php#register-staff?status=success");
} else {
   
    header("Location: http://localhost/cms/admin/test.php#register-staff?status=error");
}

// Close the statement and connection
$stmt->close();
$conn->close();
exit();
?>
