<?php
session_start(); // Start session

// Database credentials
require_once 'conn.php';

// Get form data
$user = $_POST['regno'];
$pass = $_POST['password'];

// Hash the provided password with MD5
$hashed_password = md5($pass);

// Prepare SQL statement to check the students table
$sql = "SELECT student_id, regno , fullname FROM students WHERE regno = ? AND password = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error preparing the statement: " . $conn->error);
}

$stmt->bind_param("ss", $user, $hashed_password);
$stmt->execute();
$result = $stmt->get_result();

// Check if student user exists and password matches
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Successful login
    $_SESSION['student_id'] = $row['student_id'];
    $_SESSION['fullname'] = $row['fullname'];
    $_SESSION['role'] = 'student'; // Set role as 'student'

    // Redirect to student-specific page
    header("Location: ../student/index.php");
    exit();
} else {
    // Set error message in session
    $_SESSION['login_error'] = "Invalid username or password.";
    // Redirect back to the login form
    header("Location: ../index.php");
    exit();
}

// Close the connection
$stmt->close();
$conn->close();
?>
