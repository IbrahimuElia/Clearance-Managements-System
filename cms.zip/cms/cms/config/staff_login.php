<?php
session_start(); // Start session

// Database credentials
require_once 'conn.php';

// Get form data
$user = $_POST['username'];
$pass = $_POST['password'];

// Hash the provided password with MD5
$hashed_password = md5($pass);

// Prepare SQL statement
$sql = "SELECT id, username, role FROM staff WHERE username = ? AND password = ?";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    die("Error preparing the statement: " . $conn->error);
}

$stmt->bind_param("ss", $user, $hashed_password);
$stmt->execute();
$result = $stmt->get_result();

// Check if user exists and password matches
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    // Successful login
    $_SESSION['user_id'] = $row['id'];
    $_SESSION['username'] = $row['username'];
    $_SESSION['role'] = $row['role']; // Store role in session

    // Redirect based on user role
    switch ($_SESSION['role']) {
        case 'admin':
            header("Location: ../admin/index.php");
            break;
        case 'finance':
            header("Location: ../finance/index.php");
            break;
        case 'cisco':
            header("Location: ../cisco/index.php");
            break;
        case 'workshop':
            header("Location: ../workshop/index.php");
            break;
            case 'librarian':
                header("Location: ../library/index.php");
                break;
        default:
            echo "Unknown role.";
            break;
    }
    exit();
} 
 else {
        // Set error message in session
        $_SESSION['login_error'] = "Invalid username or password.";
        // Redirect back to the login form
        header("Location: ../index.php");
        exit();
}

// Close the connection
$stmt->close();
$conn->close();
?>
