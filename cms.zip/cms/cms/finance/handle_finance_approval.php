<?php
require_once '../config/conn.php';

// Get form data and validate
$requestId = intval($_POST['clear_id']);
$approve = isset($_POST['approve']);
$reject = isset($_POST['reject']);
$financeComment = $_POST['finance_comment'] ?? '';
$totalAmount = $_POST['total_amount'] ?? '0';
$debtItems = $_POST['debt_items'] ?? '[]';
$customAmounts = $_POST['custom_amounts'] ?? []; // Ensure this key is correct

if ($requestId <= 0) {
    die("Invalid request ID.");
}

// Function to generate a numeric control number
function generateControlNumber() {
    $prefix = '99'; // Fixed prefix
    $length = 10; // Length of the random numeric part
    $controlNumber = $prefix;

    // Generate a random numeric string of specified length
    for ($i = 0; $i < $length; $i++) {
        $controlNumber .= rand(0, 9); // Append a random digit (0-9)
    }

    return $controlNumber;
}

// Prepare to update request status and dashboard status
if ($approve && !$reject) {
    $status = 'Pending Cisco Approval';
    $stmt = $conn->prepare("UPDATE clearance_requests SET status = ?, rejected_status = 'Approved' , finance_view_reject = 'No' WHERE clear_id = ?");
    
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("si", $status, $requestId);

    if ($stmt->execute()) {
        // Update the dashboard status
        $result = $conn->query("SELECT student_id FROM clearance_requests WHERE clear_id = $requestId");

        if ($result && $row = $result->fetch_assoc()) {
            $studentId = (int)$row['student_id'];
            $dashboardStatus = 'Coordinator Approved';
            $stmt = $conn->prepare("UPDATE students SET finance_dashboard_status = ? WHERE student_id = ?");

            if (!$stmt) {
                die("Prepare failed: " . $conn->error);
            }

            $stmt->bind_param("si", $dashboardStatus, $studentId);

            if ($stmt->execute()) {
                echo "Request approved by Coordinator and student dashboard status updated.";
            } else {
                echo "Error updating dashboard status: " . $stmt->error;
            }
        } else {
            echo "No student found for the given request ID.";
        }
    } else {
        echo "Error updating request status: " . $stmt->error;
    }
} elseif ($reject && !$approve) {
    $status = 'Finance Rejected';
    $controlNumber = generateControlNumber(); // Generate control number
    $rejectionDate = date('Y-m-d H:i:s'); // Get current date and time

    // Encode custom amounts to JSON
    $customAmountsJson = json_encode($customAmounts);

    // Prepare the SQL query to include custom amounts
    $stmt = $conn->prepare("UPDATE clearance_requests SET status = ?, rejected_status = 'Hahahah Finance', finance_view_reject = 'No', finance_comment = ?, total_amount = ?, debt_items = ?, custom_amount = ?, control_number = ?, finance_date = ? WHERE clear_id = ?");
    
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("sssssssi", $status, $financeComment, $totalAmount, $debtItems, $customAmountsJson, $controlNumber, $rejectionDate, $requestId);

    if ($stmt->execute()) {
        // Update the dashboard status
        $result = $conn->query("SELECT student_id FROM clearance_requests WHERE clear_id = $requestId");

        if ($result && $row = $result->fetch_assoc()) {
            $studentId = (int)$row['student_id'];
            $dashboardStatus = 'Finance Rejected';
            $stmt = $conn->prepare("UPDATE students SET finance_dashboard_status = ? WHERE student_id = ?");
            
            if (!$stmt) {
                die("Prepare failed: " . $conn->error);
            }

            $stmt->bind_param("si", $dashboardStatus, $studentId);
            $stmt->execute();

            echo "Request rejected by Finance and student dashboard status updated.";
        } else {
            echo "No student found for the given request ID.";
        }
    } else {
        echo "Error updating request status: " . $stmt->error;
    }
} else {
    die("Invalid action. Please choose either approve or reject.");
}

// Close statements and connection
$stmt->close();
$conn->close();

?>