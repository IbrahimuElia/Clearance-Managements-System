<?php
require_once '../config/conn.php';

// Check if the request method is POST and 'clear_id' and 'approve' fields are set
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['clear_id']) && isset($_POST['approve'])) {
    // Get and sanitize form data
    $requestId = intval($_POST['clear_id']);
    $approve = $_POST['approve'] === 'true'; // Convert to boolean

    if ($approve) {
        // Approve the request directly
        $status = 'Pending Cisco Approval';

        // Prepare the statement for updating the clearance request
        $stmt = $conn->prepare("UPDATE clearance_requests SET status = ?, rejected_status = 'Approved' WHERE clear_id = ?");
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("si", $status, $requestId);
        if ($stmt->execute()) {
            // Update the dashboard status
            $result = $conn->query("SELECT student_id FROM clearance_requests WHERE clear_id = $requestId");
            if (!$result) {
                die("Query failed: " . $conn->error);
            }

            $studentId = (int)$result->fetch_assoc()['student_id'];
            $dashboardStatus = 'Finance Approved';

            // Prepare the statement for updating the student's dashboard status
            $stmt = $conn->prepare("UPDATE students SET finance_dashboard_status = ? WHERE student_id = ?"); // Removed the comma before WHERE
            if (!$stmt) {
                die("Prepare failed: " . $conn->error);
            }

            $stmt->bind_param("si", $dashboardStatus, $studentId);
            if ($stmt->execute()) {
                echo "Request approved by Finance and student dashboard status updated.";
            } else {
                echo "Error updating dashboard status: " . $stmt->error;
            }
        } else {
            echo "Error updating request status: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Approval not granted.";
    }
} else {
    die("Invalid request. Please check the data being sent.");
}

$conn->close();
?>
