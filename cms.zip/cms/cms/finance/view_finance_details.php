
<html>
  <head>
    <title> Finance - CMS</title> 
  </head>

<?php
require_once '../config/conn.php';

// Get request ID from URL
$requestId = intval($_GET['id']);

// Fetch request details
$sql = "SELECT * FROM clearance_requests WHERE clear_id = ?";
$stmt = $conn->prepare($sql);

// Check if prepare() was successful
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("i", $requestId);
$stmt->execute();
$result = $stmt->get_result();
$request = $result->fetch_assoc();

if ($request) {
    // Fetch student debts
    $studentId = $request['student_id'];
    $sql = "SELECT * FROM student_debts WHERE student_id = ? AND status = 'Unpaid'";
    $stmt = $conn->prepare($sql);

    // Check if prepare() was successful
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("i", $studentId);
    $stmt->execute();
    $debts = $stmt->get_result();

    if ($debts->num_rows > 0) {
        echo "<h3>Outstanding Debts</h3>";
        echo "<table border='1' cellpadding='10' cellspacing='0'>
                <tr>
                    <th>Debt ID</th>
                    <th>Amount</th>
                    <th>Status</th>
                </tr>";
        while($debt = $debts->fetch_assoc()) {
            echo "<tr>
                    <td>" . htmlspecialchars($debt['id']) . "</td>
                    <td>" . htmlspecialchars($debt['amount']) . "</td>
                    <td>" . htmlspecialchars($debt['status']) . "</td>
                  </tr>";
        }
        echo "</table>";
        echo "<form action='handle_finance_approval.php' method='post'>
                <input type='hidden' name='id' value='" . htmlspecialchars($request['id']) . "'>
                <input type='submit' name='approve' value='Approve' " . ($debts->num_rows > 0 ? "disabled" : "") . ">
                <input type='submit' name='reject' value='Reject'>
              </form>";
    } else {
        echo "<p>No outstanding debts.</p>";
        echo "<form action='handle_finance_approval.php' method='post'>
                <input type='hidden' name='id' value='" . htmlspecialchars($request['clear_id']) . "'>
                <input type='submit' name='approve' value='Approve'>
                <input type='submit' name='reject' value='Reject'>
              </form>";
    }
} else {
    echo "Request not found.";
}

$stmt->close();
$conn->close();
?>
</html>