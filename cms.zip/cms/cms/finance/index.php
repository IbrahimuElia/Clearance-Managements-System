<?php
session_start(); // Start session

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /cms"); // Redirect to login if not logged in
    exit();
}

require_once '../config/conn.php'; // Ensure this path is correct

$sql = "SELECT * FROM clearance_requests WHERE status = 'Pending Finance Approval' ORDER BY request_date DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finance - CMS</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <style>/* Custom CSS for forms */
.dash-content form {
    display: flex;
    flex-direction: column;
    max-width: 800px; /* Increased max-width for a wider form */
    margin: 20px auto;
    padding: 30px;
    background-color: var(--panel-color);
    border-radius: 10px;
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.1);
    border: 1px solid var(--border-color);
}

/* Grid container for form inputs */
.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr; /* Two columns layout */
    gap: 20px; /* Space between grid items */
    margin-bottom: 20px; /* Space below the grid */
}

/* Style for grid items */
.grid-item {
    display: flex;
    flex-direction: column;
}

/* Style for input fields */
.dash-content form input[type="text"],
.dash-content form select {
    width: 100%;
    padding: 12px;
    margin-bottom: 10px; /* Reduced margin-bottom to fit better within grid */
    border: 1px solid var(--border-color);
    border-radius: 8px;
    background-color: var(--panel-color);
    color: var(--text-color);
    font-size: 16px;
    font-weight: 400;
    outline: none;
    transition: border-color 0.3s ease, background-color 0.3s ease;
}

.dash-content form input[type="text"]:focus,
.dash-content form select:focus {
    border-color: var(--primary-color);
    background-color: var(--box3-color);
}

/* Style for submit button */
.dash-content form button {
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    background-color: var(--primary-color);
    color: var(--panel-color);
    font-size: 16px;
    font-weight: 500;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.2s ease;
}

.dash-content form button:hover {
    background-color: #0b3cc1;
    transform: translateY(-2px);
}

.dash-content form button:active {
    transform: translateY(1px);
}

/* Style for labels */
.dash-content form label {
    font-size: 16px;
    font-weight: 500;
    color: var(--text-color);
    margin-bottom: 5px;
    display: block;
}

body {
    font-family: Arial, Helvetica, sans-serif;
    margin: 0;
    padding: 0;
}

* {
    box-sizing: border-box;
}

.open-button {
    background-color: #555;
    color: white;
    padding: 16px 20px;
    border: none;
    cursor: pointer;
    opacity: 0.8;
    position: fixed;
    bottom: 23px;
    right: 28px;
    width: 280px;
    font-size: 16px;
    font-weight: 500;
    transition: background-color 0.3s;
}

.open-button:hover {
    background-color: #0b3cc1;
    opacity: 1;
}

.form-popup {
    display: none;
    position: fixed;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    border: 3px solid #f1f1f1;
    background-color: white;
    z-index: 9;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    max-width: 400px;
    width: 100%;
    padding: 20px;
}

.form-container {
    display: flex;
    flex-direction: column;
}

.form-container .section {
    display: none;
}

.form-container .active {
    display: block;
}

.form-container input[type=text], 
.form-container input[type=password] {
    width: 100%;
    padding: 15px;
    margin: 5px 0 22px 0;
    border: 1px solid #ddd;
    border-radius: 5px;
    background: #f1f1f1;
}

.form-container input[type=text]:focus, 
.form-container input[type=password]:focus {
    background-color: #ddd;
    outline: none;
}

.section-buttons {
    display: flex;
    justify-content: space-between; /* Space out the buttons */
    gap: 10px; /* Space between buttons */
    margin-top: 10px; /* Space above buttons */
}

.btn, .approve-btn {
    padding: 12px 20px;
    border: none;
    cursor: pointer;
    font-size: 14px; /* Smaller font size for better fit */
    font-weight: 500;
    border-radius: 5px;
    transition: background-color 0.3s, transform 0.3s;
    text-align: center;
    display: flex;
    align-items: center;
    justify-content: center;
    flex: 1; /* Allow buttons to grow and fit the container */
}

.btn {
    background-color: #04AA6D;
    color: white;
}

.btn:hover {
    background-color: #0b3cc1;
}

.btn.cancel {
    background-color: red;
}

.btn.cancel:hover {
    background-color: darkred;
}

.approve-btn {
    background-color: #0056b3; /* Dark blue background */
    color: white;
}

.approve-btn:hover {
    background-color: #004494; /* Darker blue on hover */
    transform: scale(1.05); /* Slightly enlarge the button */
}

.approve-btn:active {
    background-color: #003366; /* Even darker blue on click */
    transform: scale(0.98); /* Slightly shrink the button on click */
}

#checkboxContainer {
    display: flex;
    flex-direction: column;
    margin-top: 20px;
}

#checkboxContainer label {
    margin: 5px 0;
    display: flex;
    align-items: center;
    font-size: 16px;
}

#checkboxContainer input[type=checkbox] {
    margin-right: 10px;
    transform: scale(1.2);
}

</style>
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <img src="images/logo.png" alt="Logo">
            </div>
            <span class="logo_name">CMS</span>
        </div>

        <div class="menu-items">
            <ul class="nav-links">
                <li><a href="#dashboard">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dashboard</span>
                </a></li>
          
                </li>
                <li>
                    <a href="#message">
                        <i class="uil uil-message"></i>
                        <span class="link-name">Message</span>
                    </a>
                </li>
                <li>
                    <a href="#message">
                        <i class="uil uil-edit"></i>
                        <span class="link-name">Edit Profile</span>
                    </a>
                </li>
                <li>
                    <a href="#user">
                        <i class="uil uil-user"></i>
                        <span class="link-name">View Users</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="dashboard">
        <div class="top">
            <i class="uil uil-bars sidebar-toggle"></i>
            <div class="search-box">
                <i class="uil uil-search"></i>
                <input type="text" placeholder="Search here...">
            </div>
            <?php echo "Welcome, " . htmlspecialchars($_SESSION['username']) . "!"; ?>
            <div class="profile-menu">
                <img src="images/profile.jpg" alt="Profile Image" id="profile-img">
                <div class="dropdown-content" id="dropdown-content">
                    <a href="edit-profile.php">Edit Profile</a>
                    <a href="../logout.php">Log Out</a>
                </div>
            </div>
        </div>

        <section id="dashboard" class="section show">
            <div class="dash-content">
       
                <div class="activity">
                    <div class="title">
                        <i class="uil uil-clock-three"></i>
                        <span class="text">Pending Clearance</span>
                    </div>
                    <?php
// Assuming you have already included the database connection script

// Query to fetch the clearance requests

// Output data in a table
if ($result->num_rows > 0) {
    echo "<table style='width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8f9fa; color: #343a40;'>
            <thead style='background-color: #007bff; color: #ffffff;'>
                <tr>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Full Name</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Registration No</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Branch</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Course</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Session</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Clearance Date</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Action</th>
                </tr>
            </thead>
            <tbody>";

    while ($row = $result->fetch_assoc()) {
        echo "<tr style='background-color: #ffffff;'>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['full_name']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['regno']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['branch']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['course']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['session_type']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['request_date']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>
                    <a href='#' class='view-details' data-id='{$row['clear_id']}' 
                       style='display: inline-block; padding: 8px 16px; font-size: 14px; font-weight: bold; color: #ffffff; background-color: #007bff; border: none; border-radius: 5px; text-decoration: none; text-align: center; cursor: pointer; transition: background-color 0.3s ease;'>
                       View
                    </a>
                </td>
              </tr>";
    }
    echo "</tbody>
        </table>";
} else {
    echo "<p>No requests pending approval.</p>";
}
?>

<div class="form-popup" id="myForm" style="display:none;">
    <form class="form-container">
        <div class="section" id="noDebtSection">
            <h1>No Debt</h1>
            <p>You have no debts to manage at the moment.</p>
            <div class="section-buttons">
                <button type="button" class="approve-btn" id="approveBtn">Approve</button>
                <button type="button" class="btn" onclick="showCheckDebt()">Reject</button>
                <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
            </div>
        </div>

        <div class="section" id="checkDebtSection" style="display:none;">
            <h1>Check Debt</h1>
            <p>Select to add debt:</p>
            <div id="checkboxContainer">
                <div class="subject-group">
                    <label>
                        <input type="checkbox" name="debtItem" value="Last Semester Fees" data-amount="0" onchange="toggleInput(this)"> Last Semester Fees
                        <input type="number" name="customAmount[]" class="custom-amount" placeholder="Enter amount" style="display: none;" oninput="calculateTotal()" />
                    </label><br>
                </div>
                <div class="subject-group">
                    <label>
                        <input type="checkbox" name="debtItem" value="ID Return Penalty" data-amount="20000" onchange="toggleInput(this)"> ID Return Penalty
                        <span>Tsh 20,000</span>
                    </label><br>
                </div>
            </div>

            <h3>Total Amount Due: <span id="totalAmount">Tsh 0</span></h3>
            <label for="finance_comment">Finance Comment:</label><br>
            <textarea id="finance_comment" name="finance_comment"></textarea><br>
            <input type="hidden" id="controlNumber" name="control_number" value="">
            <div class="section-buttons">
                <button type="button" class="btn" onclick="sendReject()">Reject</button>
                <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
            </div>
        </div>
    </form>
</div>
<div class="overview">
  
                <div class="activity">
                    <div class="title">
                        <i class="uil uil-clock-three"></i>
                        <span class="text">Rejected Finance Clearance</span>
                    </div>

<?php
 $sql = "SELECT * FROM clearance_requests WHERE finance_view_reject = 'yes' ORDER BY request_date DESC";
 $result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "<table style='width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8f9fa; color: #343a40;'>
            <thead style='background-color: #007bff; color: #ffffff;'>
                <tr>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Full Name</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Registration No</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Branch</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Course</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Debt</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Reason Reapply</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Receipt</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Action</th>
                </tr>
            </thead>
            <tbody>";

    while ($row = $result->fetch_assoc()) {
        $debtItems = json_decode($row['debt_items'], true);
        echo "<tr style='background-color: #ffffff;'>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['full_name']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['regno']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['branch']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['course']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>";

        if (!empty($debtItems)) {
            echo "<h3 style='margin: 0;'>Debt Items:</h3><ul style='list-style-type: disc; margin-left: 20px;'>";
            foreach ($debtItems as $item) {
                echo "<li>" . htmlspecialchars($item) . "</li>";
            }
            echo "</ul>";
        } else {
            echo "No debt items.";
        }
        echo "<p> Control Number: {$row['control_number']}</p>";

        echo "</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['finance_reapply_reasons']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>";

        if (!empty($row['finance_comment'])) {
            echo "<a href='" . htmlspecialchars($row['finance_comment']) . "' target='_blank' style='color: #007bff; text-decoration: underline;'>View Document</a>";
        } else {
            echo "No document available";
        }

        echo "</td>
             <td style='padding: 12px; border: 1px solid #dee2e6;'>
                    <a href='#' class='view-details' data-id='{$row['clear_id']}' 
                       style='display: inline-block; padding: 8px 16px; font-size: 14px; font-weight: bold; color: #ffffff; background-color: #007bff; border: none; border-radius: 5px; text-decoration: none; text-align: center; cursor: pointer; transition: background-color 0.3s ease;'>
                       View
                    </a>
                </td>
          </tr>";
    }

    echo "</tbody>
        </table>";
} else {
    echo "<p>No requests pending approval.</p>";
}

$conn->close();
?>
<script>
let currentClearId;

document.addEventListener('DOMContentLoaded', function () {
    const viewButtons = document.querySelectorAll('.view-details');

    viewButtons.forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault(); // Prevent the default anchor behavior
            currentClearId = this.getAttribute('data-id'); // Get the clear_id
            document.getElementById('controlNumber').value = generateControlNumber(); // Generate control number
            openForm(); // Open the form
        });
    });
});

function openForm() {
    document.getElementById("myForm").style.display = "block";
    showNoDebt();
}

function closeForm() {
    document.getElementById("myForm").style.display = "none";
}

function showNoDebt() {
    document.getElementById("noDebtSection").style.display = "block";
    document.getElementById("checkDebtSection").style.display = "none";
}

function showCheckDebt() {
    document.getElementById("noDebtSection").style.display = "none";
    document.getElementById("checkDebtSection").style.display = "block";
    calculateTotal();  // Update total when switching sections
}

function toggleInput(checkbox) {
    const inputField = checkbox.nextElementSibling; // Get the associated input
    if (checkbox.value === "Last Semester Fees") {
        inputField.style.display = checkbox.checked ? 'block' : 'none'; // Show/hide input field
    } else {
        inputField.style.display = 'none'; // Hide input field for ID Return Penalty
    }
    calculateTotal(); // Update total when toggling input
}

function calculateTotal() {
    const checkboxes = document.querySelectorAll('#checkboxContainer input[type=checkbox]:checked');
    let total = 0;

    checkboxes.forEach(checkbox => {
        const baseAmount = parseInt(checkbox.getAttribute('data-amount'), 10) || 0; // Get base amount from data attribute
        total += baseAmount; // Add base amounts to total
        if (checkbox.value === "Last Semester Fees") {
            const customInput = checkbox.nextElementSibling; // Get the associated custom input
            const customAmount = parseInt(customInput.value, 10) || 0; // Get custom amount or default to 0
            total += customAmount; // Add custom amount to total
        }
    });

    document.getElementById('totalAmount').textContent = `Tsh ${total}`;
}

function sendReject() {
    const checkedItems = Array.from(document.querySelectorAll('#checkboxContainer input[type=checkbox]:checked'))
                              .map(checkbox => checkbox.value);
    const customAmounts = Array.from(document.querySelectorAll('#checkboxContainer input[type=checkbox]:checked'))
                               .map(checkbox => {
                                   if (checkbox.value === "Last Semester Fees") {
                                       const customInput = checkbox.nextElementSibling;
                                       // Convert the custom input value to a string formatted as a decimal
                                       return customInput.value ? parseFloat(customInput.value).toFixed(2) : "0.00";
                                   }
                                   return "0.00"; // Return a string for no custom input
                               });

    const financeComment = document.getElementById('finance_comment').value;
    const controlNumber = document.getElementById('controlNumber').value;

    const data = new URLSearchParams({
        clear_id: currentClearId,
        debt_items: JSON.stringify(checkedItems),
        custom_amounts: JSON.stringify(customAmounts), // This will be in the format ["675.00", "0.00"]
        finance_comment: financeComment,
        total_amount: document.getElementById('totalAmount').textContent.replace('Tsh ', '').trim(),
        control_number: controlNumber,
        reject: "true" // Send as string
    });

    console.log("Sending rejection data:", data.toString()); // Debugging log

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "handle_finance_approval.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send(data.toString());

    xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
            showModal(xhr.responseText);
        } else {
            showModal("Failed to process rejection: " + xhr.statusText);
        }
    };

    xhr.onerror = function() {
        showModal("An error occurred while processing your request.");
    };

    closeForm(); // Close form after submission
}


document.getElementById('approveBtn').addEventListener('click', function() {
    const data = new URLSearchParams({
        clear_id: currentClearId,
        finance_comment: document.getElementById('finance_comment').value,
        total_amount: document.getElementById('totalAmount').textContent.replace('Tsh ', '').trim(),
        control_number: document.getElementById('controlNumber').value,
        approve: "true" // Send as string
    });

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "handle_finance_approval.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    console.log("Sending approval data:", data.toString()); // Debugging log
    xhr.send(data.toString());

    xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
            showModal(xhr.responseText);
        } else {
            showModal("Failed to process approval: " + xhr.statusText);
        }
    };

    xhr.onerror = function() {
        showModal("An error occurred while processing your request.");
    };

    closeForm(); // Close form after submission
});

function showModal(message) {
    document.getElementById('modalMessage').textContent = message;
    document.getElementById('responseModal').style.display = 'block';
    document.getElementById('overlay').style.display = 'block';
}

function closeModal() {
    document.getElementById('responseModal').style.display = 'none';
    document.getElementById('overlay').style.display = 'none';
}

// Initialize total calculation on checkbox change and input change
document.querySelectorAll('#checkboxContainer input[type=checkbox]').forEach(checkbox => {
    checkbox.addEventListener('change', calculateTotal);
});
document.querySelectorAll('#checkboxContainer input[type=number]').forEach(input => {
    input.addEventListener('input', calculateTotal);
});

function generateControlNumber() {
    // Replace with your control number generation logic
    return '999' + Math.floor(Math.random() * 100000);
}
</script>





<!-- Modal HTML -->
<div id="responseModal" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); width:300px; background-color:white; border:1px solid #ddd; border-radius:5px; box-shadow:0px 0px 10px rgba(0,0,0,0.2); z-index:1000;">
    <div style="padding:20px;">
        <span id="modalMessage"></span>
        <button onclick="closeModal()" style="display:block; margin-top:10px; padding:10px; background-color:#007bff; color:white; border:none; border-radius:5px; cursor:pointer;">Close</button>
    </div>
</div>

<!-- Overlay for Modal -->
<div id="overlay" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:999;"></div>

        </section><section id="register-staff" class="section">
            <div class="dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="uil uil-tachometer-fast-alt"></i>
                        <span class="text">Register Staff</span>
                    </div>
                    <div class="boxes">
                        <div class="form-container">
                            <form method="POST" action="register_staff.php">
                                <div class="form-grid">
                                    <div class="grid-item">
                                        <label for="firstname">First Name:</label>
                                        <input type="text" name="firstname" id="firstname" placeholder="First Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="lastname">Last Name:</label>
                                        <input type="text" name="lastname" id="lastname" placeholder="Last Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="email">Email:</label>
                                        <input type="email" name="email" id="email" placeholder="Email" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="password">Password:</label>
                                        <input type="password" name="password" id="password" placeholder="Password" required>
                                    </div>
                                </div>
                                <button type="submit">Register</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section><section id="register-student" class="section">
            <div class="dash-content">
                <div class="overview">
                    <div class="title">
                        <i class="uil uil-tachometer-fast-alt"></i>
                        <span class="text">Register Student</span>
                    </div>
                    <div class="boxes">
                        <div class="form-container">
                            <form method="POST" action="register_student.php">
                                <div class="form-grid">
                                    <div class="grid-item">
                                        <label for="firstname">First Name:</label>
                                        <input type="text" name="firstname" id="firstname" placeholder="First Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="lastname">Last Name:</label>
                                        <input type="text" name="lastname" id="lastname" placeholder="Last Name" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="regno">Reg No:</label>
                                        <input type="text" name="regno" id="regno" placeholder="Reg No" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="email">Email:</label>
                                        <input type="email" name="email" id="email" placeholder="Email" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="password">Password:</label>
                                        <input type="password" name="password" id="password" placeholder="Password" required>
                                    </div>
                                    <div class="grid-item">
                                        <label for="branch">Branch:</label>
                                        <select name="branch" id="branch" required>
                                            <option value="" disabled selected>Select Branch</option>
                                            <option value="Dodoma Branch">Dodoma Branch</option>
                                            <option value="Dar es Salaam Main Branch">Dar es Salaam (Main)</option>
                                            <option value="Mbeya Branch">Mbeya Branch</option>
                                        </select>
                                    </div>
                                    <div class="grid-item">
                                        <label for="course">Course:</label>
                                        <select name="course" id="course" required>
                                            <option value="" disabled selected>Select Course</option>
                                            <option value="DCIT">Diploma in Information Communication Technology</option>
                                            <option value="DBIT">Diploma in Business Information Technology</option>
                                        </select>
                                    </div>
                                    <div class="grid-item">
                                        <label for="session_type">Session:</label>
                                        <select name="session_type" id="session_type" required>
                                            <option value="" disabled selected>Select Session</option>
                                            <option value="Morning">Morning</option>
                                            <option value="Evening">Evening</option>
                                        </select>
                                    </div>
                                </div>
                                <button type="submit">Register Student</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="message" class="section">
        <div class="dash-content">
            <div class="activity">
                <div class="title">
                    <i class="uil uil-clock-three"></i>
                    <span class="text">Rejected Clearance</span>
                </div>
                <?php
require_once '../config/conn.php';

$sql = "SELECT * FROM clearance_requests WHERE rejected_status = 'Rejected Finance' ORDER BY request_date DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<table style='width: 100%; border-collapse: collapse; margin: 20px 0; background-color: #f8f9fa; color: #343a40;'>
            <thead style='background-color: #007bff; color: #ffffff;'>
                <tr>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Full Name</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Registration No</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Branch</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Course</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Debt</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Reason Reapply</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Receipt</th>
                    <th style='padding: 12px; border: 1px solid #dee2e6; text-align: left; font-size: 18px; font-weight: 500;'>Action</th>
                </tr>
            </thead>
            <tbody>";

    while ($row = $result->fetch_assoc()) {
        $debtItems = json_decode($row['debt_items'], true);
        echo "<tr style='background-color: #ffffff;'>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['full_name']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['regno']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['branch']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['course']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>";

        if (!empty($debtItems)) {
            echo "<h3 style='margin: 0;'>Debt Items:</h3><ul style='list-style-type: disc; margin-left: 20px;'>";
            foreach ($debtItems as $item) {
                echo "<li>" . htmlspecialchars($item) . "</li>";
            }
            echo "</ul>";
        } else {
            echo "No debt items.";
        }
        echo "<p> Control Number: {$row['control_number']}</p>";

        echo "</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>{$row['finance_reapply_reasons']}</td>
                <td style='padding: 12px; border: 1px solid #dee2e6;'>";

        if (!empty($row['finance_comment'])) {
            echo "<a href='" . htmlspecialchars($row['finance_comment']) . "' target='_blank' style='color: #007bff; text-decoration: underline;'>View Document</a>";
        } else {
            echo "No document available";
        }

        echo "</td>
            <td style='padding: 12px; border: 1px solid #dee2e6;'>
                <a href='#' id='approveBtn' onclick='confirmApproveRequest({$row['clear_id']})' style='display: inline-block; padding: 8px 16px; font-size: 14px; font-weight: bold; color: #ffffff; background-color: #28a745; border: none; border-radius: 5px; text-decoration: none; text-align: center; cursor: pointer; transition: background-color 0.3s ease;'>Approve</a>
            </td>
          </tr>";
    }

    echo "</tbody>
        </table>";
} else {
    echo "<p>No requests pending approval.</p>";
}

$conn->close();
?>

<script>
function confirmApproveRequest(clearId) {
    const confirmation = confirm("Are you sure you want to approve this request?");
    if (confirmation) {
        approveRequest(clearId);
    }
}

function approveRequest(clearId) {
    const data = new URLSearchParams({
        clear_id: clearId,
        approve: 'true' // Include any other necessary parameters here
    });

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "handle_rejection_approval.php", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.send(data.toString());

    xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 300) {
            alert("Request approved successfully.");
            location.reload(); // Reload the page to reflect changes
        } else {
            alert("Failed to approve the request.");
        }
    };

    xhr.onerror = function() {
        alert("An error occurred while processing your request.");
    };
}
</script>


            </div>
        </div>

        <div id="overlay" onclick="closeForm()"></div>

        <!-- Form Popup -->
        <div class="form-popup" id="approveReapply">
            <form class="form-container" onsubmit="return false;">
                <h1>Approve Request</h1>
                <p>Do you want to approve this request?</p>
                <div class="section-buttons">
                    <button type="button" id="approveBtn" onclick="approveRequest()">Approve</button>
                    <button type="button" class="btn cancel" onclick="closeForm()">Close</button>
                </div>
            </form>
        </div>
    </section>
        
        <script>
            // JavaScript to handle navigation between sections
            const sections = document.querySelectorAll('.section');
            const navLinks = document.querySelectorAll('nav a');

            navLinks.forEach(link => {
                link.addEventListener('click', (event) => {
                    event.preventDefault();
                    const targetSection = document.getElementById(link.hash.substr(1));

                    sections.forEach(section => {
                        section.classList.remove('show');
                    });

                    targetSection.classList.add('show');
                });
            });

            // JavaScript to fetch and display student details
            document.addEventListener("DOMContentLoaded", function() {
                document.querySelectorAll('.view-details').forEach(link => {
                    link.addEventListener('click', function(event) {
                        event.preventDefault();
                        const id = this.getAttribute('data-id');
                        fetchStudentDetails(id);
                    });
                });
            });

            function fetchStudentDetails(id) {
                fetch(`handle_rejection.php?id=${id}`)
                    .then(response => response.text())
                    .then(data => {
                        document.getElementById('student-details').innerHTML = data;
                    })
                    .catch(error => console.error('Error fetching student details:', error));
            }
        </script>
    </div>
</body>
</html>
