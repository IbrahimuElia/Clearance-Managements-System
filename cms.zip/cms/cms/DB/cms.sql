-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 25, 2024 at 04:36 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `clearance`
--

CREATE TABLE `clearance` (
  `clearance_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `regno` varchar(50) NOT NULL,
  `clearance_status` int(11) NOT NULL,
  `date_submitted` date NOT NULL,
  `session_type` enum('Morning','Evening') NOT NULL,
  `branch` enum('Dodoma','Dar es Salaam') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `clearance_requests`
--

CREATE TABLE `clearance_requests` (
  `clear_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `full_name` varchar(150) NOT NULL,
  `regno` varchar(100) NOT NULL,
  `phone` int(10) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `course` varchar(100) NOT NULL,
  `session_type` varchar(100) NOT NULL,
  `request_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `coordinator_approved` tinyint(1) DEFAULT 0,
  `status` varchar(50) DEFAULT 'Pending Coordinator',
  `coordinator_reapplication_reason` text DEFAULT NULL,
  `coordinator_document_path` varchar(255) DEFAULT NULL,
  `rejected_status` enum('Hahahah','Approved','Rejected Finance','Rejected Coordinator','Rejected Coordinator Reapply','Waiting Coordinator Approval','Pending Finance Approval','Hahahah Finance') NOT NULL DEFAULT 'Waiting Coordinator Approval',
  `id_returned` tinyint(1) DEFAULT 0,
  `rejection_reasons` text DEFAULT NULL,
  `reapplyReason` text NOT NULL,
  `date_conducted` date DEFAULT NULL,
  `coordinator_comments` text DEFAULT NULL,
  `finance_document` varchar(255) NOT NULL,
  `finance_rejection_reasons` text NOT NULL,
  `coordinater_view_reject` enum('Yes','No') NOT NULL DEFAULT 'No',
  `finance_reapply_reasons` text NOT NULL,
  `finance_date` date DEFAULT NULL,
  `finance_comment` text NOT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `debt_items` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`debt_items`)),
  `control_number` varchar(15) DEFAULT NULL,
  `custom_amount` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`custom_amount`)),
  `finance_view_reject` enum('No','Yes') NOT NULL DEFAULT 'No',
  `cisco_view_reject` enum('No','Yes') NOT NULL DEFAULT 'No',
  `cisco_reapply_reasons` text NOT NULL,
  `workshop_view_reject` enum('No','Yes') NOT NULL DEFAULT 'No',
  `workshop_reapply_reasons` text NOT NULL,
  `librarian_view_reject` enum('No','Yes') NOT NULL DEFAULT 'No',
  `librarian_reapply_reasons` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `clearance_requests`
--

INSERT INTO `clearance_requests` (`clear_id`, `student_id`, `full_name`, `regno`, `phone`, `branch`, `course`, `session_type`, `request_date`, `coordinator_approved`, `status`, `coordinator_reapplication_reason`, `coordinator_document_path`, `rejected_status`, `id_returned`, `rejection_reasons`, `reapplyReason`, `date_conducted`, `coordinator_comments`, `finance_document`, `finance_rejection_reasons`, `coordinater_view_reject`, `finance_reapply_reasons`, `finance_date`, `finance_comment`, `total_amount`, `debt_items`, `control_number`, `custom_amount`, `finance_view_reject`, `cisco_view_reject`, `cisco_reapply_reasons`, `workshop_view_reject`, `workshop_reapply_reasons`, `librarian_view_reject`, `librarian_reapply_reasons`) VALUES
(1, 1, 'Student Student Student', '03-4445-67-89890', 677899940, 'Dodoma', 'DCIT', 'Morning', '2024-09-16 02:45:52', 0, 'Completed', NULL, NULL, '', 0, NULL, '', NULL, NULL, '', '', 'No', '', NULL, '', NULL, '\"[\\\"RAM\\\",\\\"Hard Disk\\\",\\\"Mouse\\\"]\"', NULL, NULL, 'No', 'No', 'hellow', 'No', 'hello', 'No', 'hello'),
(2, 2, 'test test', '03-4445-67-89891', 99, 'Dodoma', 'DCIT', 'Morning', '2024-09-16 04:03:52', 0, 'Cisco Rejected', NULL, NULL, '', 0, NULL, '', NULL, NULL, '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(3, 3, 'ibra ibra', '03-4445-67-89811', 677899940, 'Dodoma', 'DCIT', 'Morning', '2024-09-18 03:08:33', 0, 'Completed', NULL, NULL, '', 0, NULL, '', NULL, NULL, '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(4, 4, 'hello hello', '03-4445-67-89833', 677899940, 'Dodoma', 'DCIT', 'Morning', '2024-09-18 13:11:28', 0, 'Approved', 'Wait', '../uploads/coordinatorReapply/PPT_Crashing.pdf', '', 0, 'Insufficient Documentation, Late Submission', '', '2024-09-19', NULL, '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(5, 5, 'juma juma', '03-4445-67-89855', 677899940, 'Dodoma', 'DCIT', 'Morning', '2024-09-19 01:49:54', 0, 'Rejected', NULL, NULL, '', 0, NULL, '', NULL, NULL, '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(6, 6, 'elia elia', '03-4445-67-89822', 677899940, 'Dodoma', 'DCIT', 'Evening', '2024-09-19 02:02:59', 0, 'Approved', NULL, NULL, '', 0, NULL, '', NULL, NULL, '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(7, 8, 'leah leah', '03-4445-67-89899', 78, 'Dodoma', 'DCIT', 'Evening', '2024-09-19 02:14:46', 0, 'Approved', NULL, NULL, '', 0, NULL, '', NULL, NULL, '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(10, 10, 'Mukasa Mukasa', '03-4445-67-89966', 78, 'Dodoma', 'DCIT', 'Evening', '2024-09-19 04:35:52', 0, 'Approved', NULL, NULL, '', 0, NULL, '', NULL, NULL, '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(27, 15, '1 1', '1', 1, 'Dodoma', 'DCIT', 'Morning', '2024-09-20 03:21:40', 0, 'Rejected', NULL, '../uploads/coordinatorReapply/cms.pdf', 'Approved', 0, 'ERGRG', 'yuhbjuhj', '2024-09-20', '', '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(28, 16, '2 2', '2', 1, 'Dodoma', 'DCIT', 'Evening', '2024-09-20 03:57:30', 0, 'Finance Rejected', '34trgtr', '../uploads/coordinatorReapply/cms.pdf', '', 0, 'Insufficient Documentation, Late Submission, Non-compliance with Guidelines, Other, fefrrgg', 'hellow i need this', '2024-09-20', '', '', '', 'No', '', NULL, 'kn', '765000.00', '[\"Last Semester Fees - Tsh700,000\",\"Direct Cost - Tsh45,000\",\"ID Return Penalty - Tsh20,000\"]', NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(29, 17, '5 5', '5', 5, 'Dodoma', 'DCIT', 'Morning', '2024-09-20 07:29:05', 0, 'Rejected', 'bgtrg', '../uploads/coordinatorReapply/cms.pdf', '', 0, 'Insufficient Documentation, Late Submission, Non-compliance with Guidelines, Other, hfghgh', '', '2024-09-20', '', '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(30, 18, '1 9', '9', 9, 'Dodoma', 'DCIT', 'Morning', '2024-09-20 08:20:28', 0, 'Rejected', NULL, NULL, '', 0, NULL, '', NULL, NULL, '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(31, 19, 'i i', 'i', 9, 'Dodoma', 'DCIT', 'Morning', '2024-09-20 09:01:54', 0, 'Rejected', NULL, NULL, '', 0, NULL, '', NULL, NULL, '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(32, 20, '12 12', '12', 12, 'Dodoma', 'DCIT', 'Morning', '2024-09-20 09:20:45', 0, 'Pending Workshop Approval', NULL, '../uploads/coordinatorReapply/cms.pdf', '', 0, 'Insufficient Documentation, Late Submission, Non-compliance with Guidelines, Other', 'I will update you later', '2024-09-20', '', '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(33, 21, 'u u', 'u', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-20 10:18:46', 0, 'Completed', NULL, '../uploads/coordinatorReapply/cms.pdf', 'Approved', 0, 'Insufficient Documentation, Late Submission, Non-compliance with Guidelines, Other, y6', 'yujgfg', '2024-09-20', '', '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(34, 22, 'q q', 'q', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-20 10:40:26', 0, 'Completed', NULL, '../uploads/coordinatorReapply/cms.pdf', 'Approved', 0, 'Late Submission, Non-compliance with Guidelines, q', 'errg', '2024-09-20', '', '', '', 'No', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(35, 26, 'v v', 'v', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-22 22:04:10', 0, 'Finance Rejected', NULL, NULL, 'Approved', 0, 'No ID', '', '2024-09-23', '', '', '', 'No', '', NULL, 'Hellow', '765000.00', '[\"Last Semester Fees - Tsh700,000\",\"Direct Cost - Tsh45,000\",\"ID Return Penalty - Tsh20,000\"]', NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(36, 27, 'lo lo', 'lo', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-23 02:22:48', 0, 'Pending Workshop Approval', NULL, NULL, 'Approved', 0, NULL, '', NULL, NULL, '../uploads/coordinatorReapply/cms.pdf', '', 'No', 'I have paid ', '2024-09-23', 'You have to pay before ', '765000.00', '[\"Last Semester Fees - Tsh700,000\",\"Direct Cost - Tsh45,000\",\"ID Return Penalty - Tsh20,000\"]', '990000000000', NULL, 'No', 'No', '', 'No', '', 'No', ''),
(37, 28, 'vb vb', 'vb', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-23 03:00:57', 0, 'Pending Workshop Approval', NULL, NULL, 'Approved', 0, NULL, '', NULL, NULL, '../uploads/coordinatorReapply/Untitled.pdf', '', 'No', 'bfb', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(38, 28, 'vb vb', 'vb', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-23 03:00:59', 0, 'Cisco Rejected', NULL, NULL, '', 0, NULL, '', NULL, NULL, '../uploads/coordinatorReapply/Untitled.pdf', '', 'No', 'bfb', '2024-09-23', 'Pay now', '745000.00', '\"[\\\"RAM\\\",\\\"Hard Disk\\\"]\"', '990000000000', NULL, 'No', 'No', '', 'No', '', 'No', ''),
(40, 30, 'y y', 'y', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-24 20:02:28', 0, 'Finance Rejected', NULL, NULL, 'Approved', 0, 'Systems Analysis and Design, Sup, Enterprise Networking and Security, Sup, Web Application Development, Sup', '', '2024-09-25', '', '', '', 'No', '', '2024-09-25', '', '40000.00', '[\"Last Semester Fees\",\"ID Return Penalty\"]', '990000000000', NULL, 'No', 'No', '', 'No', '', 'No', ''),
(51, 39, 'toto toto', 'toto', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-25 06:28:22', 0, 'Cisco Rejected', NULL, NULL, '', 0, NULL, '', NULL, NULL, '../uploads/coordinatorReapply/students_list_2024-09-24.pdf', '', '', 'yyu', '2024-09-25', '', '20000.00', '\"[\\\"ccna 1\\\"]\"', '995410455776', '\"[\\\"0.00\\\"]\"', 'No', 'No', '', 'No', '', 'No', ''),
(52, 40, 'tete tete', 'tete', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-25 07:29:40', 0, 'Rejected', NULL, NULL, 'Approved', 0, NULL, '', NULL, NULL, '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(53, 41, 'titi titi', 'titi', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-25 07:32:01', 0, 'Rejected', NULL, NULL, 'Approved', 0, NULL, '', NULL, NULL, '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(54, 42, 'hello hello', 'hello', 0, 'Dar es Salaam', 'DCIT', 'Morning', '2024-09-25 11:37:56', 0, 'Completed', NULL, NULL, 'Approved', 0, NULL, '', NULL, NULL, '', '', '', '', NULL, '', NULL, NULL, NULL, NULL, 'No', 'No', '', 'No', '', 'No', ''),
(55, 44, 'ibra ibra', 'ibra', 67, 'Dodoma', 'DCIT', 'Morning', '2024-09-25 12:04:40', 0, 'Completed', NULL, NULL, 'Approved', 0, 'Systems Analysis and Design, Inco, Enterprise Networking and Security, Inco', 'he', '2024-09-25', '', '', '', '', 'Nimelipa', '2024-09-25', '', '40000.00', '\"[\\\"ccna 1\\\"]\"', '997015066861', '\"[\\\"20000.00\\\",\\\"0.00\\\"]\"', 'No', 'No', '', 'No', '', 'No', ''),
(56, 45, 'latest latest', 'latest', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-25 12:43:40', 0, 'Completed', NULL, NULL, 'Approved', 0, 'Essentials of Project Management, Inco', 'Nimefanya', '2024-09-25', '', '', '', '', 'nimelipa', '2024-09-25', '', '220000.00', '\"[\\\"ccna 1\\\",\\\"ccna 2\\\"]\"', '998435306974', '\"[\\\"200000.00\\\",\\\"0.00\\\"]\"', 'No', 'No', '', 'No', '', 'No', ''),
(57, 46, 'another another', 'another', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-25 12:51:06', 0, 'Processing Finance Reapply', NULL, NULL, 'Rejected Finance', 0, 'Systems Analysis and Design, Inco, Enterprise Networking and Security, Inco', 'Nimemaliza', '2024-09-25', '', '', '', '', 'Nimelipa', '2024-09-25', '', '220000.00', '[\"Last Semester Fees\",\"ID Return Penalty\"]', '995761070118', '\"[\\\"200000.00\\\",\\\"0.00\\\"]\"', 'Yes', 'No', '', 'No', '', 'No', ''),
(58, 47, 'tina tina', 'tina', 0, 'Dodoma', 'DCIT', 'Morning', '2024-09-25 12:57:24', 0, 'Completed', NULL, NULL, 'Approved', 0, 'Systems Analysis and Design, Inco, Enterprise Networking and Security, Inco', 'Nimefanya', '2024-09-25', '', '', '', '', 'Nimelipa', '2024-09-25', '', '220000.00', '\"[\\\"Fundamentals of Enterprise Networking\\\",\\\"Server Administration\\\"]\"', '993126270039', '\"[\\\"200000.00\\\",\\\"0.00\\\"]\"', 'No', 'No', 'Nimefanya', 'No', '', 'No', 'Hello');

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_length` text COLLATE utf8_bin DEFAULT NULL,
  `col_collation` varchar(64) COLLATE utf8_bin NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) COLLATE utf8_bin DEFAULT '',
  `col_default` text COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `settings_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `export_type` varchar(10) COLLATE utf8_bin NOT NULL,
  `template_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `template_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin DEFAULT NULL,
  `data_sql` longtext COLLATE utf8_bin DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `role` varchar(50) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `role`, `firstname`, `lastname`, `username`, `email`, `password`) VALUES
(1, 'admin', 'Admin', 'Admin', 'admin', 'admin@admin.com', '21232f297a57a5a743894a0e4a801fc3'),
(2, 'finance', 'Finance', 'Department', 'finance', 'finance@finance.com', '57336afd1f4b40dfd9f5731e35302fe5'),
(3, 'cisco', 'Cisco', 'Department', 'cisco', 'cisco@cisco.com', 'dfeaf10390e560aea745ccba53e044ed'),
(4, 'workshop', 'Workshop', 'Workshop', 'workshop', 'workshop@workshop.com', '33f2ee11f1130c5c6e11061cc91d9b9a'),
(5, 'librarian', 'Libranian', 'Librarian', 'librarian', 'librarian@librarian.com', '35fa1bcb6fbfa7aa343aa7f253507176');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `fullname` varchar(500) NOT NULL,
  `regno` varchar(20) NOT NULL,
  `branch` enum('Dodoma','Dar es Salaam') NOT NULL,
  `course` varchar(200) NOT NULL,
  `session_type` enum('Morning','Evening') NOT NULL,
  `clearance_status` int(1) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `dashboard_status` text NOT NULL,
  `finance_dashboard_status` enum('Pending Approval','Finance Approved','Finance Rejected') DEFAULT 'Pending Approval',
  `cisco_dashboard_status` enum('Pending Finance Approval','Cisco Approved','Cisco Rejected') DEFAULT 'Pending Finance Approval',
  `workshop_dashboard_status` enum('Pending Cisco Approval','Workshop Approved','Workshop Rejected') DEFAULT 'Pending Cisco Approval',
  `librarian_dashboard_status` enum('Pending Workshop Approval','Librarian Approved','Librarian Rejected') DEFAULT 'Pending Workshop Approval',
  `coordinator_dashboard_status` enum('Not Requested','Coordinator Approved','Coordinator Rejected') DEFAULT 'Not Requested',
  `rejected_date` date DEFAULT NULL,
  `coordinator_status_date` date DEFAULT NULL,
  `coordinator_status` enum('Approved','Rejected') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `fullname`, `regno`, `branch`, `course`, `session_type`, `clearance_status`, `email`, `password`, `dashboard_status`, `finance_dashboard_status`, `cisco_dashboard_status`, `workshop_dashboard_status`, `librarian_dashboard_status`, `coordinator_dashboard_status`, `rejected_date`, `coordinator_status_date`, `coordinator_status`) VALUES
(1, 'Student Student Student', '03-4445-67-89890', 'Dodoma', 'DCIT', 'Morning', 2, 'student@student.com', 'cd73502828457d15655bbd7a63fb0bc8', 'Status: Approved.', 'Finance Approved', 'Cisco Approved', 'Workshop Approved', 'Librarian Approved', 'Coordinator Approved', NULL, NULL, NULL),
(2, 'test test', '03-4445-67-89891', '', 'DCIT', 'Morning', 2, 'test@test.com', '098f6bcd4621d373cade4e832627b4f6', '', 'Finance Approved', 'Cisco Rejected', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(3, 'ibra ibra', '03-4445-67-89811', '', 'DCIT', 'Morning', 2, 'ibra@gmail.com', '0b5ffc09eb62ef2241f07327276ee064', '', 'Finance Approved', 'Cisco Approved', 'Workshop Approved', 'Librarian Approved', 'Coordinator Approved', NULL, NULL, NULL),
(4, 'leah leah', '03-4445-67-89833', '', 'DBIT', 'Evening', 2, 'test100@gmail.com', '7007e0cd908f10b946fe03b518d6bc1f', '', 'Pending Approval', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, '0000-00-00', 'Approved'),
(5, 'new new', '03-4445-67-89855', '', 'DBIT', 'Morning', 2, 'new@gmail.com', '22af645d1859cb5ca6da0c484f1f37ea', '', 'Finance Approved', 'Cisco Rejected', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(6, 'elia elia', '03-4445-67-89822', '', 'DBIT', 'Evening', 2, 'elia@gmail.com', '9773bf404d60e43e693b5bde0e7e1df0', '', 'Pending Approval', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, '2024-09-19', 'Approved'),
(8, 'leah leah', '03-4445-67-89899', '', 'DCIT', 'Evening', 2, 'test1000@gmail.com', '7007e0cd908f10b946fe03b518d6bc1f', '', 'Pending Approval', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, '2024-09-19', 'Approved'),
(10, 'Mukasa Mukasa', '03-4445-67-89966', '', 'DBIT', 'Evening', 2, 'test10040@gmail.com', '7007e0cd908f10b946fe03b518d6bc1f', '', 'Pending Approval', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, '0000-00-00', 'Approved'),
(15, '1 1', '1', '', 'DCIT', 'Morning', 2, '1@y.com', 'c4ca4238a0b923820dcc509a6f75849b', '', 'Finance Approved', 'Cisco Rejected', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(16, '2 2', '2', '', 'DCIT', 'Evening', 2, '2@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', '', 'Finance Rejected', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Rejected', NULL, NULL, NULL),
(17, '5 5', '5', '', 'DCIT', 'Morning', 2, '5@gmail.com', 'e4da3b7fbbce2345d7772b0674a318d5', '', 'Finance Approved', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Rejected', NULL, NULL, NULL),
(18, '1 9', '9', '', 'DCIT', 'Morning', 2, '9@gmail.com', '45c48cce2e2d7fbdea1afc51c7c6ad26', '', 'Finance Approved', 'Cisco Rejected', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(19, 'i i', 'i', '', 'DCIT', 'Morning', 2, 'i@gmail.com', '865c0c0b4ab0e063e5caa3387c1a8741', '', 'Pending Approval', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Rejected', NULL, NULL, NULL),
(20, '12 12', '12', '', 'DCIT', 'Morning', 2, '1@gmail.com', 'c20ad4d76fe97759aa27a0c99bff6710', '', 'Finance Approved', 'Cisco Approved', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Rejected', NULL, NULL, NULL),
(21, 'u u', 'u', '', 'DCIT', 'Morning', 2, 'u@gm.vom', '7b774effe4a349c6dd82ad4f4f21d34c', '', 'Finance Approved', 'Cisco Approved', 'Workshop Approved', 'Librarian Approved', 'Coordinator Approved', NULL, NULL, NULL),
(22, 'q q', 'q', '', 'DCIT', 'Morning', 2, 'q@gmail.com', '7694f4a66316e53c8cdd9d9954bd611d', '', 'Finance Approved', 'Cisco Approved', 'Workshop Approved', 'Librarian Approved', 'Coordinator Approved', NULL, NULL, NULL),
(23, 'h h', 'h', '', 'DCIT', 'Morning', 0, 'h@gmail.com', '2510c39011c5be704182423e3a695e91', '', 'Pending Approval', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Not Requested', NULL, NULL, NULL),
(24, 's s', 's', '', 'DCIT', 'Morning', 0, 's@gmail.com', '03c7c0ace395d80182db07ae2c30f034', '', 'Pending Approval', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Not Requested', NULL, NULL, NULL),
(25, 'k k', 'k', '', 'DCIT', 'Morning', 0, 'k@gmail.com', '8ce4b16b22b58894aa86c421e8759df3', '', 'Pending Approval', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Not Requested', NULL, NULL, NULL),
(26, 'v v', 'v', '', 'DCIT', 'Morning', 2, 'v@gmail.com', '9e3669d19b675bd57058fd4664205d2a', '', 'Finance Rejected', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(27, 'lo lo', 'lo', '', 'DCIT', 'Morning', 2, 'lo@gmail.com', '7ce8636c076f5f42316676f7ca5ccfbe', '', 'Finance Approved', 'Cisco Approved', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(28, 'vb vb', 'vb', '', 'DCIT', 'Morning', 2, 'vb@gmail.com', '2ab4f27ab1ffdcdad8ed21a965ca62ad', '', 'Finance Approved', 'Cisco Approved', 'Workshop Rejected', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(30, 'y y', 'y', '', 'DCIT', 'Morning', 0, 'y@gmail.com', '415290769594460e2e485922904f345d', '', 'Finance Rejected', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(39, 'toto toto', 'toto', 'Dodoma', 'DCIT', 'Morning', 2, 'toto@gmail.com', 'f71dbe52628a3f83a77ab494817525c6', '', 'Finance Rejected', 'Cisco Approved', 'Workshop Rejected', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(40, 'tete tete', 'tete', 'Dodoma', 'DCIT', 'Morning', 2, 'tete@mail.com', '2db313fabca57504d9dc776e46b304f6', '', 'Pending Approval', 'Cisco Approved', 'Workshop Rejected', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(41, 'titi titi', 'titi', 'Dodoma', 'DCIT', 'Morning', 2, 'titi@gmail.com', '5d933eef19aee7da192608de61b6c23d', '', 'Pending Approval', 'Cisco Approved', 'Workshop Approved', 'Librarian Rejected', 'Coordinator Approved', NULL, NULL, NULL),
(42, 'hello hello', 'hello', 'Dar es Salaam', 'DCIT', 'Morning', 2, 'hello@gmail.com', '5d41402abc4b2a76b9719d911017c592', '', '', 'Cisco Approved', 'Workshop Approved', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(44, 'ibra ibra', 'ibra', 'Dodoma', 'DCIT', 'Morning', 2, 'ibra@gma.com', '0b5ffc09eb62ef2241f07327276ee064', '', '', 'Cisco Rejected', 'Workshop Approved', 'Librarian Approved', 'Coordinator Approved', NULL, NULL, NULL),
(45, 'latest latest', 'latest', 'Dodoma', 'DCIT', 'Morning', 2, 'latest@gmail.com', '71ccb7a35a452ea8153b6d920f9f190e', '', '', 'Cisco Rejected', 'Workshop Approved', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(46, 'another another', 'another', 'Dodoma', 'DCIT', 'Morning', 2, 'another@gmail.com', 'b32d73e56ec99bc5ec8f83871cde708a', '', 'Finance Rejected', 'Pending Finance Approval', 'Pending Cisco Approval', 'Pending Workshop Approval', 'Coordinator Approved', NULL, NULL, NULL),
(47, 'tina tina', 'tina', 'Dodoma', 'DCIT', 'Morning', 2, 'tina@ggg.com', 'ef2afe0ea76c76b6b4b1ee92864c4d5c', '', '', 'Cisco Approved', 'Workshop Approved', 'Librarian Rejected', 'Coordinator Approved', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_debts`
--

CREATE TABLE `student_debts` (
  `id` int(11) NOT NULL,
  `student_id` int(11) DEFAULT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `status` enum('Unpaid','Paid') DEFAULT 'Unpaid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `clearance`
--
ALTER TABLE `clearance`
  ADD PRIMARY KEY (`clearance_id`);

--
-- Indexes for table `clearance_requests`
--
ALTER TABLE `clearance_requests`
  ADD PRIMARY KEY (`clear_id`);

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD UNIQUE KEY `regno` (`regno`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `student_debts`
--
ALTER TABLE `student_debts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `student_id` (`student_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `clearance`
--
ALTER TABLE `clearance`
  MODIFY `clearance_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clearance_requests`
--
ALTER TABLE `clearance_requests`
  MODIFY `clear_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- AUTO_INCREMENT for table `student_debts`
--
ALTER TABLE `student_debts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `student_debts`
--
ALTER TABLE `student_debts`
  ADD CONSTRAINT `student_debts_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
