<?php
require_once '../config/conn.php';
// Get request ID from the query string
$requestId = intval($_GET['id']);

// Fetch request details
$sql = "SELECT * FROM clearance_requests WHERE clear_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $requestId);
$stmt->execute();
$result = $stmt->get_result();
$request = $result->fetch_assoc();


// Display the approval frm
echo "<form action='handle_cisco_approval.php' method='post'>
        <input type='hidden' name='id' value='" . htmlspecialchars($request['clear_id']) . "'>";

if ($request['status'] == 'Pending Cisco Approval') {
    echo "<input type='submit' name='approve' value='Approve'>
          <input type='submit' name='reject' value='Reject'>
          </form>";
} else {
    echo "<p>This request is not pending Cisco approval.</p>";
}

echo "<a href='view_all_requests.php'>Back to all requests</a>";

$stmt->close();
$conn->close();
?>
