<?php
session_start(); // Start session
// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /cms"); // Redirect to login if not logged in
    exit();
}
// Assuming the user role is stored in the session
$userRole = $_SESSION['role'] ?? null;

// Define the required role for this page
$requiredRole = 'cisco'; // Required role

// Check if the user has the required role
if ($userRole !== $requiredRole) {
     header("Location: /cms"); // Redirect to login if not logged in
    exit();
}
require_once '../config/conn.php';
$sql = "SELECT * FROM clearance_requests WHERE status = 'Pending Cisco Approval' ORDER BY request_date DESC";
$result = $conn->query($sql);

?>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Cisco - CMS</title> 
    <style>


.message {
            padding: 10px;
            margin: 20px;
            border-radius: 5px;
            display: none;
        }
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }


    </style>
</head>
<body>
    <nav>
        <div class="logo-name">
            <div class="logo-image">
                <img src="images/logo.png" alt="">
            </div>

            <span class="logo_name">CMS</span>
        </div>

        <div class="menu-items">
        <ul class="nav-links">
                <li><a href="#dashboard">
                    <i class="uil uil-estate"></i>
                    <span class="link-name">Dashboard</span>
                </a></li>
                <!-- <li class="dropdown">
                    <a href="#">
                        <i class="uil uil-user form-icon"></i>
                        <span class="link-name">Register User</span>
                        <i class="uil uil-angle-down dropdown-icon"></i>
                    </a>
                    <ul class="dropdown-menu nav-links">
                        <li><a href="#register-staff">Staff</a></li>
                        <li><a href="#register-student">Student</a></li>
                    </ul>
                </li> -->
                <li>
                    <a href="#message">
                        <i class="uil uil-message"></i>
                        <span class="link-name">Message</span>
                    </a>
                </li>
                <li>
                    <a href="#user">
                        <i class="uil uil-user"></i>
                        <span class="link-name">View Users</span>
                    </a>
                </li>
            </ul>
        </div>
    </nav>

    <div class="dashboard">
    <div class="top">
    <i class="uil uil-bars sidebar-toggle"></i>

    <div class="search-box">
        <i class="uil uil-search"></i>
        <input type="text" placeholder="Search here...">
    </div>

    <?php echo "Welcome, " . htmlspecialchars($_SESSION['username']) . "!"; ?>

    <div class="profile-menu">
        <img src="images/profile.jpg" alt="" id="profile-img">
        <div class="dropdown-content" id="dropdown-content">
            <a href="edit-profile.php">Edit Profile</a>
            <a href="../logout.php">Log Out</a>
        </div>
    </div>
</div>
<section id="dashboard" class="section show">
        <div class="dash-content">
            <div class="overview">
                <div class="title">
                    <i class="uil uil-tachometer-fast-alt"></i>
                    <span class="text">Dashboard</span>
                </div>

                <div class="boxes">
                    <div class="box box1">
                        <i class="uil uil-thumbs-up"></i>
                        <span class="text">Total Likes</span>
                        <span class="number">50,120</span>
                    </div>
                    <div class="box box2">
                        <i class="uil uil-comments"></i>
                        <span class="text">Comments</span>
                        <span class="number">20,120</span>
                    </div>
                    <div class="box box3">
                        <i class="uil uil-share"></i>
                        <span class="text">Total Share</span>
                        <span class="number">10,120</span>
                    </div>
                </div>
            </div>

            <div class="activity">
                <div class="title">
                    <i class="uil uil-clock-three"></i>
                    <span class="text">Recent Activity</span>
                </div>

                <!-- anza hapa+ -->
                <?php

// Output data in divs
if ($result->num_rows > 0) {
    echo "<div class='activity-data'>";

    while ($row = $result->fetch_assoc()) {
        echo "<div class='data names'>
                <span class='data-title'>Full Name</span>
                <span class='data-list'>{$row['full_name']}</span>

              </div>";
              echo "<div class='data names'>
              <span class='data-title'>Registration No</span>
              <span class='data-list'>{$row['regno']}</span>

            </div>";
              echo "<div class='data names'>
              <span class='data-title'>Branch</span>
              <span class='data-list'>{$row['branch']}</span>

            </div>";
            echo "<div class='data names'>
            <span class='data-title'>Course</span>
            <span class='data-list'>{$row['course']}</span>

          </div>";
          echo "<div class='data names'>
          <span class='data-title'>Session</span>
          <span class='data-list'>{$row['session_type']}</span>

        </div>";
        echo "<div class='data names'>
        <span class='data-title'>Clearance Date</span>
        <span class='data-list'>{$row['request_date']}</span>

      </div>";
      echo "<div class='data names'>
      <span class='data-title'>Action</span>
      <a href='#' class='view-details' data-id='{$row['clear_id']}'>View</a>

    </div>";


             
    }

    echo "</div>";
} else {
    echo "No requests pending approval.";
}
?>
<!-- Container to display student details -->
<div id="student-details"></div>

<script>
document.addEventListener("DOMContentLoaded", function() {
    document.querySelectorAll('.view-details').forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const id = this.getAttribute('data-id');
            fetchStudentDetails(id);
        });
    });
});

function fetchStudentDetails(id) {
    fetch(`cisco_approval_view.php?id=${id}`)
        .then(response => response.text())
        .then(data => {
            document.getElementById('student-details').innerHTML = data;
        })
        .catch(error => console.error('Error fetching student details:', error));
}
</script>


                <!-- Mwisho hapa -->
            </div>
        </div>
       </section>
     <section id="register-staff" class="section">
     <div class="dash-content">
            <div class="overview">
                <div class="title">
                    <i class="uil uil-tachometer-fast-alt"></i>
                    <span class="text">Register Staff</span>
                </div>

                <div class="boxes">
                <div class="dash-content">
                    <form method="POST" action="register_staff.php">
                    <label for="role">Role:</label>
    <select name="role" id="role" required>
        <option value="" disabled selected>Select your role</option>
        <option value="finance">Finance(Administrative Assistance)</option>
        <option value="cisco">Cisco Coordinator</option>
        <option value="workshop">Workshop</option>
        <option value="librarian">Librarian</option>
    </select>
                    <input type="text" name="firstname" placeholder="First Name" required>
                    <input type="text" name="lastname" placeholder="Last Name" required>
                        <input type="text" name="username" placeholder="Username" required>
                        <input type="email" name="email" placeholder="Email" required>
                       <input type="password" name="password" placeholder="Password" required>
                       <button type="submit">Register</button>
                     </form>
                     
                </div>
                </div>
            </div>
        </div>
     </section>
     <section id="register-student" class="section">
     <div class="dash-content">
            <div class="overview">
                <div class="title">
                    <i class="uil uil-tachometer-fast-alt"></i>
                    <span class="text">Register Student</span>
                </div>

                <div class="boxes">
                <div class="form-container">
                    <form method="POST" action="request_clearance.php">
                        <label for="firstname">First Name:</label>
                        <input type="text" name="firstname" id="firstname" placeholder="First Name" required>

                        <label for="lastname">Last Name:</label>
                        <input type="text" name="lastname" id="lastname" placeholder="Last Name" required>
                        <label for="regno">Reg No:</label>
                        <input type="text" name="regno" id="regno" placeholder="Reg No" required>

                        <label for="email">Email:</label>
                        <input type="email" name="email" id="email" placeholder="Email" required>

                        <label for="password">Password:</label>
                        <input type="password" name="password" id="password" placeholder="Password" required>

                        <label for="branch">Branch:</label>
                        <select name="branch" id="branch" required>
                            <option value="Dodoma Branch">Dodoma Branch</option>
                            <option value="Dar es Salaam  Main Branch">Dar es Salaam (Main)</option>
                            <option value="Mbeya Branch">Mbeya Branch</option>
                        </select>

                        <label for="course">Course:</label>
                        <select name="course" id="course" required>
                            <option value="DCIT">Diploma in Information Communication Technology</option>
                            <option value="DBIT">Diploma in Business Information Technology</option>
                        </select>
                        <label for="session">Session:</label>
                        <select name="session" id="session" required>
                            <option value="" disabled selected>Select Session</option>
                            <option value="Morning">Morning</option>
                            <option value="Afternoon">Afternoon</option>
                        </select> <br>
                        <button type="submit">Register Student</button>
                    </form>
                </div>
            </div>
        </div>
     </section>
    <script>
        const sections = document.querySelectorAll('.section');
        const navLinks = document.querySelectorAll('nav a');

        navLinks.forEach(link => {
            link.addEventListener('click',  
 (event) => {
                event.preventDefault();
                const targetSection  
 = document.getElementById(link.hash.substr(1));

                sections.forEach(section => {
                    section.classList.remove('show');
                });

                targetSection.classList.add('show');
            });
        });
    </script>
      <script>
    document.getElementById('myInput').addEventListener('input', function (e) {
      let value = e.target.value;

      // Remove all non-digit characters
      value = value.replace(/\D/g, '');

      // Format the value to match the desired pattern
      if (value.length > 2) {
        value = value.slice(0, 2) + '-' + value.slice(2);
      }
      if (value.length > 6) {
        value = value.slice(0, 7) + '-' + value.slice(7);
      }
      if (value.length > 9) {
        value = value.slice(0, 10) + '-' + value.slice(10, 15); // Allow only 5 digits in the last segment
      }

      // Set the formatted value back to the input
      e.target.value = value;
    });
  </script>

    <!-- <script src="script.js"></script> -->
</body>
</html>